PACOTE SHAPEFILE — PREVINE / VULNERABILIDADE

CRS de todas as camadas: EPSG:4326 (WGS 84).
Cada camada contém .shp, .shx, .dbf, .prj e .cpg em UTF-8.
O formato Shapefile limita nomes de campos a 10 caracteres; consulte
campos.csv para a correspondência entre o nome original e o abreviado.
Ausência de ponto nas camadas de serviços não significa inexistência.
