# Fontes (dados completos oficiais)
- Agregados por Setores Censitários — Censo 2022: https://ftp.ibge.gov.br/Censos/Censo_Demografico_2022/Agregados_por_Setores_Censitarios/
  Temas usados: Básico (população, domicílios), Demografia (faixas etárias por sexo),
  Cor ou raça (indígenas; pretos + pardos), Domicílio (água por rede geral, esgoto por rede geral).
  Água (V00111) e esgoto (V00309) usam como universo os domicílios particulares
  permanentes ocupados; o denominador correto é V00001, do tema Domicílio — Parte 1.
- Rendimento do Responsável por setor — Censo 2022 (pasta à parte, publicada em 2026):
  https://ftp.ibge.gov.br/Censos/Censo_Demografico_2022/Agregados_por_Setores_Censitarios_Rendimento_do_Responsavel/
  Variável V06004 = rendimento nominal médio mensal das pessoas responsáveis.
- Malha de setores censitários 2022: https://geoftp.ibge.gov.br/organizacao_do_territorio/malhas_territoriais/malhas_de_setores_censitarios__divisoes_intramunicipais/censo_2022/
- Malha municipal 2022: https://geoftp.ibge.gov.br/organizacao_do_territorio/malhas_territoriais/malhas_municipais/municipio_2022/
- Grade estatística 2022 (células de 200m, população e domicílios): https://geoftp.ibge.gov.br/recortes_para_fins_estatisticos/grade_estatistica/censo_2022/grade_estatistica/
  Ladrilhos ID_14 e ID_15 (os que cobrem a bacia Taquari-Antas — confirmado pelo total_bounds real dos dois shapefiles).
- Limite da bacia Taquari-Antas: https://iede.rs.gov.br/server/rest/services/DRH/Bacias_Hidrograficas/MapServer/0/query?where=1%3D1&outFields=*&returnGeometry=true&f=geojson
Os CSVs aqui são o RECORTE dos municípios que intersectam a bacia; o estadual completo está nas URLs acima.
Energia elétrica não consta no agregado de características do domicílio por setor (Censo 2022).
Valores `X` omitidos pelo IBGE por sigilo estatístico não significam zero. Os
arquivos regenerados os mantêm nulos e publicam flags `sigilo_<campo>`.
