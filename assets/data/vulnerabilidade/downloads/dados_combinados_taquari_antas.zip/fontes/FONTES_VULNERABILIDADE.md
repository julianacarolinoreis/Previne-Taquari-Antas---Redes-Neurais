# Fontes (dados completos oficiais)
- Agregados por Setores Censit�rios � Censo 2022: https://ftp.ibge.gov.br/Censos/Censo_Demografico_2022/Agregados_por_Setores_Censitarios/
  Temas usados: B�sico (popula��o, domic�lios), Demografia (faixas et�rias por sexo),
  Cor ou ra�a (ind�genas; pretos + pardos), Domic�lio (�gua por rede geral, esgoto por rede geral).
  Denominador de �gua/esgoto: V00001 = Domic�lios Particulares Permanentes Ocupados (dom_ocupados).
  Valores X omitidos por sigilo estat�stico permanecem nulos e t�m flag booleana sigilo_<campo>.
- Rendimento do Respons�vel por setor � Censo 2022 (pasta � parte, publicada em 2026):
  https://ftp.ibge.gov.br/Censos/Censo_Demografico_2022/Agregados_por_Setores_Censitarios_Rendimento_do_Responsavel/
  Vari�vel V06004 = rendimento nominal m�dio mensal das pessoas respons�veis.
- Malha de setores censit�rios 2022: https://geoftp.ibge.gov.br/organizacao_do_territorio/malhas_territoriais/malhas_de_setores_censitarios__divisoes_intramunicipais/censo_2022/
- Malha municipal 2022: https://geoftp.ibge.gov.br/organizacao_do_territorio/malhas_territoriais/malhas_municipais/municipio_2022/
- Grade estat�stica 2022 (c�lulas de 200m, popula��o e domic�lios): https://geoftp.ibge.gov.br/recortes_para_fins_estatisticos/grade_estatistica/censo_2022/grade_estatistica/
  Ladrilhos ID_14 e ID_15 (os que cobrem a bacia Taquari-Antas � confirmado pelo total_bounds real dos dois shapefiles).
- Limite da bacia Taquari-Antas: https://iede.rs.gov.br/server/rest/services/DRH/Bacias_Hidrograficas/MapServer/0/query?where=1%3D1&outFields=*&returnGeometry=true&f=geojson
Os CSVs aqui s�o o RECORTE dos munic�pios que intersectam a bacia; o estadual completo est� nas URLs acima.
Energia el�trica n�o consta no agregado de caracter�sticas do domic�lio por setor (Censo 2022).
