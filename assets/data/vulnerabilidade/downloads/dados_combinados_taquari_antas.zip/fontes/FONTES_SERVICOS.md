# Fontes — pontos de serviços publicados no IEDE-RS
- bombeiros: https://iede.rs.gov.br/server/rest/services/CBM_Bombeiros/CBM_Centroide_RS_SC/MapServer/0
- escolas: https://iede.rs.gov.br/server/rest/services/Hosted/Escolas_Movimento_Massa/FeatureServer/2
- hospitais: https://iede.rs.gov.br/server/rest/services/Hosted/Hospitais_Movimento_Massa/FeatureServer/3
- ubs: https://iede.rs.gov.br/server/rest/services/SES/base_unica_unidades_saude/FeatureServer/0
Recorte: pontos dentro dos municípios que intersectam a bacia Taquari-Antas
(polígonos municipais simplificados ~120 m — pontos exatamente na divisa podem
cair fora). As camadas têm coberturas diferentes e não devem ser tratadas como
inventário completo: ausência de ponto não prova ausência do serviço.
Os cadastros estaduais consultados estão nas URLs acima.
O pacote publicado foi gerado em 18/08/2026 (UTC); a data de atualização
original de cada cadastro estadual não é informada pelo serviço consultado.
