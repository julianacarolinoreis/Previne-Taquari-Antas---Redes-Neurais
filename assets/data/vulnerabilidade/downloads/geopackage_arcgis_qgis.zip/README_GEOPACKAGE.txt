PACOTE GEOPACKAGE — PREVINE / VULNERABILIDADE

Arquivo: previne_vulnerabilidade.gpkg
CRS de todas as camadas: EPSG:4326 (WGS 84).
Os nomes originais e os nomes dos layers estão em camadas.csv.
O GeoPackage preserva os nomes completos dos campos, ao contrário
do Shapefile, que limita nomes a dez caracteres.
Ausência de ponto nas camadas de serviços não significa inexistência.
