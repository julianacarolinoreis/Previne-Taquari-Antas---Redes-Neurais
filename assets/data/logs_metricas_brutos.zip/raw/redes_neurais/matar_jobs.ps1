# Script para matar 2h_alt_extras e Filas_D, mantendo 2h_conv

$outFile = "D:\PREVINE\redes_neurais\matar_jobs_resultado.txt"
$result = @()

# 1. Listar todos os matlab.exe com comandos
$matlabs = Get-WmiObject Win32_Process -Filter "name='matlab.exe'" | Select-Object ProcessId, CommandLine, @{N='StartTime';E={$_.ConvertToDateTime($_.CreationDate)}}
$result += "=== MATLAB processes ==="
foreach ($m in $matlabs) {
    $result += "PID=$($m.ProcessId) Start=$($m.StartTime) CMD=$($m.CommandLine)"
}

# 2. Matar matlab com "run_all_2h_alt" no cmdline (2h_alt_extras)
$killed2hAlt = @()
foreach ($m in $matlabs) {
    if ($m.CommandLine -like "*run_all_2h_alt*") {
        Stop-Process -Id $m.ProcessId -Force
        $killed2hAlt += $m.ProcessId
        $result += "KILLED 2h_alt_extras MATLAB PID=$($m.ProcessId)"
    }
}

# 3. Listar e matar CMD com "rodar_todas_filas" ou "rodar_filas_D"
$cmds = Get-WmiObject Win32_Process -Filter "name='cmd.exe'" | Select-Object ProcessId, CommandLine
$result += "=== CMD processes ==="
foreach ($c in $cmds) {
    $result += "PID=$($c.ProcessId) CMD=$($c.CommandLine)"
    if ($c.CommandLine -like "*rodar_filas*" -or $c.CommandLine -like "*filas_melhorias*") {
        # Kill this CMD and its children
        $children = Get-WmiObject Win32_Process | Where-Object {$_.ParentProcessId -eq $c.ProcessId}
        foreach ($child in $children) {
            Stop-Process -Id $child.ProcessId -Force -ErrorAction SilentlyContinue
            $result += "KILLED child PID=$($child.ProcessId) ($($child.Name))"
        }
        Stop-Process -Id $c.ProcessId -Force -ErrorAction SilentlyContinue
        $result += "KILLED Filas_D CMD PID=$($c.ProcessId)"
    }
}

# 4. Matar python.exe rodando rodar_todas_filas
$pythons = Get-WmiObject Win32_Process -Filter "name='python.exe'" | Select-Object ProcessId, CommandLine
$result += "=== Python processes ==="
foreach ($p in $pythons) {
    $result += "PID=$($p.ProcessId) CMD=$($p.CommandLine)"
    if ($p.CommandLine -like "*rodar_todas_filas*" -or $p.CommandLine -like "*rodar_alt8h*" -or $p.CommandLine -like "*rodar_alt*" -or $p.CommandLine -like "*rodar_conv*") {
        Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
        $result += "KILLED Python fila PID=$($p.ProcessId)"
    }
}

$result | Out-File $outFile -Encoding UTF8
Write-Host "Done. See $outFile"
