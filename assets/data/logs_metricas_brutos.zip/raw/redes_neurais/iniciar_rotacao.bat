@echo off
echo [%DATE% %TIME%] Iniciando fila de rotacao de eventos...
start "fila_rotacao_eventos" /MIN cmd /C "C:\Users\Usuario\AppData\Local\Python\bin\python.exe "D:\PREVINE\redes_neurais\fila_rotacao_eventos.py""
echo Fila iniciada em background (janela minimizada).
echo Log em: D:\PREVINE\redes_neurais\fila_rotacao_eventos.log
timeout /T 3
