function run_one_autoalt_rot8h(EXCEL, PLAN, input, faixaEntrada, faixaSaida, CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV, rot_id, evt_teste, evt_valida)
modelo_autoalt_rot8h;
end
