@echo off
"C:\Users\Usuario\AppData\Local\Python\pythoncore-3.14-64\python.exe" "D:\PREVINE\redes_neurais\RNA_MELHORIAS_12H_DIRIGIDAS_2026_07_03\00_SUPERVISOR\supervisor_12h_pos_filas_atuais.py"
