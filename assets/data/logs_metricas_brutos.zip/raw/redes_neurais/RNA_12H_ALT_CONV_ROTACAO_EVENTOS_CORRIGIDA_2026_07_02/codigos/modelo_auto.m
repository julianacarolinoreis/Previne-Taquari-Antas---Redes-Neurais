% SCRIPT PARA PREVISAO DE SERIE TEMPORAL COM REDES NEURAIS ARTIFICIAIS:
% INCLUI:
% - DIVISAO PRE-DEFINIDA DAS AMOSTRAS
% - TRANSFORMACAO DOS DADOS DE ENTRADA (ESCALONAMENTO POR NORMALIZACAO)
% - TREINAMENTO PELO ALGORITMO RETROPROPAGATIVO (BACKPROPAGATION)
% - VALIDACAO CRUZADA PARA EVITAR SUPERAJUSTAMENTO DA REDE
% - ARMAZENAMENTO DOS RESULTADOS E RECURSOS DE PLOTAGEM
% CRIADO POR: Guilherme Garcia de Oliveira
% ATUALIZADO EM: 29/10/2023, 23:30.

clearvars -except PLAN input EXCEL CEL SERIE faixaEntrada faixaSaida nh nit Cic file gravarExcel arquivoCSV
close all
clc
tic

disp('Carregando dados... MODELO CONVENCIONAL SANTA TEREZA 2H')

if ~exist('EXCEL','var'), EXCEL='RNA_SANTATEREZA_2H.xlsx'; end
if ~exist('PLAN','var'), PLAN='RNA2H_1'; end
if ~exist('input','var'), input=4; end

if ~exist('faixaEntrada','var'), faixaEntrada='I3:L5029'; end
if ~exist('faixaSaida','var'), faixaSaida='M3:M5029'; end
if ~exist('CEL','var'), CEL='N3:N5029'; end
if ~exist('SERIE','var'), SERIE='H3:H5029'; end

if ~exist('nh','var'), nh=5; end
if ~exist('nit','var'), nit=20; end
if ~exist('Cic','var'), Cic=40000; end
if ~exist('file','var'), file='RNAPREV_AUTO.mat'; end
if ~exist('gravarExcel','var'), gravarExcel=1; end
if ~exist('arquivoCSV','var'), arquivoCSV='resultados_modelos.csv'; end

DADOS=[];
DADOS(:,1:input)=xlsread(EXCEL, PLAN, faixaEntrada);
DADOS(:,input+1)=xlsread(EXCEL, PLAN, faixaSaida);

f=0.05;
Prc=0.001;
Mom=0;

% CARREGAMENTO DA DIVISAO TREINO / VALIDACAO / TESTE
X(:,1)=xlsread(EXCEL,PLAN,SERIE);
treina=[]; valida=[]; verifica=[];

for i=1:size(X,1)
    if X(i)==1
        treina=[treina; DADOS(i,:)];
    elseif X(i)==2
        valida=[valida; DADOS(i,:)];
    else
        verifica=[verifica; DADOS(i,:)];
    end
end

disp('Carregamento de dados concluida!')

% FUNCOES PRONTAS - INLINES
unisig=inline('1./(1+exp(-n))');
dunisig=inline('max(a.*(1-a),0.01)');
limsup=inline('max(v,[],2)+(max(v,[],2)-min(v,[],2)).*f','v','f');
liminf=inline('min(v,[],2)-(max(v,[],2)-min(v,[],2)).*f','v','f');
esclin=inline('(v-b*u)./(a*u)','v','a','b','u');
reclin=inline('(a*u).*s+b*u','s','a','b','u');

% SEPARACAO ENTRE MATRIZES DE INPUTS E OUTPUTS
Pt=treina(:,1:input)'; Tt=treina(:,input+1:end)';
Ptv=valida(:,1:input)'; Ttv=valida(:,input+1:end)';
Pv=verifica(:,1:input)'; Tv=verifica(:,input+1:end)';
Ptot=DADOS(:,1:input)'; Ttot=DADOS(:,input+1:end)';

% OUTRAS DEFINICOES
EVmin=1000000000000000;
As=unisig; Ds=dunisig; Ah=unisig; Dh=dunisig;

Ut=ones(1,size(Pt,2));
Utv=ones(1,size(Ptv,2));
Uv=ones(1,size(Pv,2));
Utot=ones(1,size(Ptot,2));

% TRANSFORMACAO DOS DADOS
disp('Realizando o escalonamento dos dados...')

ae=std(Pt,[],2);
be=mean(Pt,2);

ls=limsup(Tt,f);
li=liminf(Tt,f);
au=ls-li;
bu=li;

pt=esclin(Pt,ae,be,Ut);
ptv=esclin(Ptv,ae,be,Utv);
pv=esclin(Pv,ae,be,Uv);
ptot=esclin(Ptot,ae,be,Utot);

tt=esclin(Tt,au,bu,Ut);
ttv=esclin(Ttv,au,bu,Utv);
tv=esclin(Tv,au,bu,Uv);
ttot=esclin(Ttot,au,bu,Utot);

% TREINAMENTO COM REDES NEURAIS ARTIFICIAIS
disp('Iniciando o treinamento da rede neural artificial...')

for i=1:nit
    [wh,bh,ws,bs,J,EQ,EV,TX,DE] = Retroprvcfn2(pt,tt,ptv,ttv,Ah,Dh,As,Ds,nh,Cic,Prc,Mom);

    if EV(:,end)<EVmin
        EVmin=EV(:,end);
        save(file,'wh','bh','ws','bs','J','EQ','EV','TX','DE','ae','be','au','bu')
    end

    format bank
    disp([num2str(i/nit*100),'% CONCLUIDO'])
end

disp('Rede neural artificial treinada!')

% CALCULANDO METRICAS DE DESEMPENHO DA SIMULACAO
disp('Calculando metricas de desempenho da RNA para simulacao...')

load(file)

Tctre=reclin(As(ws*Ah(wh*pt+bh*Ut)+bs*Ut),au,bu,Ut);
Tctot=reclin(As(ws*Ah(wh*ptot+bh*Utot)+bs*Utot),au,bu,Utot);
Tc=reclin(As(ws*Ah(wh*pv+bh*Uv)+bs*Uv),au,bu,Uv);
Tcval=reclin(As(ws*Ah(wh*ptv+bh*Utv)+bs*Utv),au,bu,Utv);

eabs=abs(Tv-Tc);
emed_abs=mean(eabs);

p=[50 80 90 95 99 100];
g=prctile(eabs,p);

e2=(Tv-Tc).^2;
e2val=(Ttv-Tcval).^2;

NASH=1-sum(sum(e2))/sum(sum((Tv-mean(mean(Tv))).^2));
NASH_VAL=1-sum(sum(e2val))/sum(sum((Ttv-mean(mean(Ttv))).^2));

MPERS=verifica(:,1)';
PERS=1-sum(sum(e2))/sum(sum((Tv-MPERS).^2));

BASE_TRE=treina(:,1)'; BASE_VAL=valida(:,1)'; BASE_TESTE=verifica(:,1)'; BASE_GERAL=DADOS(:,1)';
e_tre=Tt-Tctre; e_val=Ttv-Tcval; e_tes=Tv-Tc; e_ger=Ttot-Tctot;
PERS_TREINO=1-sum(sum(e_tre.^2))/sum(sum((Tt-BASE_TRE).^2));
PERS_VALIDACAO=1-sum(sum(e_val.^2))/sum(sum((Ttv-BASE_VAL).^2));
PERS_TESTE=1-sum(sum(e_tes.^2))/sum(sum((Tv-BASE_TESTE).^2));
PERS_GERAL=1-sum(sum(e_ger.^2))/sum(sum((Ttot-BASE_GERAL).^2));
NASH_TREINO=1-sum(sum(e_tre.^2))/sum(sum((Tt-mean(mean(Tt))).^2));
NASH_TESTE=NASH;
NASH_VALIDACAO=NASH_VAL;
NASH_GERAL=1-sum(sum(e_ger.^2))/sum(sum((Ttot-mean(mean(Ttot))).^2));
MAE_TREINO=mean(abs(e_tre)); MAE_VALIDACAO=mean(abs(e_val)); MAE_TESTE=mean(abs(e_tes)); MAE_GERAL=mean(abs(e_ger));
E95_TREINO=prctile(abs(e_tre),95); E95_VALIDACAO=prctile(abs(e_val),95); E95_TESTE=prctile(abs(e_tes),95); E95_GERAL=prctile(abs(e_ger),95);
CORR_TREINO=corrcoef(Tctre,Tt); CORR_VALIDACAO=corrcoef(Tcval,Ttv); CORR_TESTE=corrcoef(Tc,Tv); CORR_GERAL=corrcoef(Tctot,Ttot);
N_GERAL=size(Ttot,2); N_TREINO=size(Tt,2); N_VALIDACAO=size(Ttv,2); N_TESTE=size(Tv,2);

CORRELACAO=corrcoef(Tc,Tv);
ERRO_RELATIVO=mean(mean(eabs./Tv));
emed_abs_mean=emed_abs/mean(mean(Tv));
e95=g(1,4);

format short

RESULTS=[NASH;PERS;CORRELACAO(1,2);ERRO_RELATIVO;emed_abs_mean;e95;NASH_VAL;J];

save(file)

disp('Coeficiente de Nash Sutcliffe teste = '), disp(num2str(NASH))
disp('Coeficiente de Nash Sutcliffe validacao = '), disp(num2str(NASH_VAL))
disp('Coeficiente de Persistencia = '), disp(num2str(PERS))
disp('Coeficiente de Correlacao = '), disp(num2str(CORRELACAO(1,2)))
disp('Erro Absoluto Medio = '), disp(num2str(emed_abs))
disp('Erro Percentual = '), disp(num2str(ERRO_RELATIVO))
disp('Erro 95% = '), disp(num2str(e95))
disp('J = '), disp(num2str(J))

% REGISTRA RESULTADO DA COMBINACAO
fid=fopen(arquivoCSV,'a');

if ftell(fid)==0
    fprintf(fid,'PLAN;nh;nit;Cic;J;NASH_VAL;NASH_TESTE;PERS;CORRELACAO;ERRO_RELATIVO;ERRO_ABS_MEDIO;E95;arquivo_mat\n');
end

fprintf(fid,'%s;%d;%d;%d;%d;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%s\n', ...
    PLAN,nh,nit,Cic,J,NASH_VAL,NASH,PERS,CORRELACAO(1,2),ERRO_RELATIVO,emed_abs,e95,file);

fclose(fid);

arquivoCSVCompleto=strrep(arquivoCSV,'.csv','_metricas_completas.csv');
fid=fopen(arquivoCSVCompleto,'a');
[~,MODELO_NOME,~]=fileparts(file);
TIPO_MODELO='conv';

if ftell(fid)==0
    fprintf(fid,'MODELO;TIPO;PLAN;input;faixaEntrada;faixaSaida;CEL;SERIE;nh;nit;Cic;J;N_GERAL;N_TREINO;N_VALIDACAO;N_TESTE;NASH_GERAL;NASH_TREINO;NASH_VALIDACAO;NASH_TESTE;PERS_GERAL;PERS_TREINO;PERS_VALIDACAO;PERS_TESTE;MAE_GERAL;MAE_TREINO;MAE_VALIDACAO;MAE_TESTE;E95_GERAL;E95_TREINO;E95_VALIDACAO;E95_TESTE;CORR_GERAL;CORR_TREINO;CORR_VALIDACAO;CORR_TESTE;arquivo_mat\n');
end

fprintf(fid,'%s;%s;%s;%d;%s;%s;%s;%s;%d;%d;%d;%d;%d;%d;%d;%d;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%s\n', ...
    MODELO_NOME,TIPO_MODELO,PLAN,input,faixaEntrada,faixaSaida,CEL,SERIE,nh,nit,Cic,J,N_GERAL,N_TREINO,N_VALIDACAO,N_TESTE,NASH_GERAL,NASH_TREINO,NASH_VALIDACAO,NASH_TESTE,PERS_GERAL,PERS_TREINO,PERS_VALIDACAO,PERS_TESTE,MAE_GERAL,MAE_TREINO,MAE_VALIDACAO,MAE_TESTE,E95_GERAL,E95_TREINO,E95_VALIDACAO,E95_TESTE,CORR_GERAL(1,2),CORR_TREINO(1,2),CORR_VALIDACAO(1,2),CORR_TESTE(1,2),file);

fclose(fid);

% GRAVA NO EXCEL SOMENTE SE VOCE PEDIR
rnaout=Tctot';

if gravarExcel==1
    xlswrite(EXCEL,rnaout,PLAN,CEL);
end

toc
