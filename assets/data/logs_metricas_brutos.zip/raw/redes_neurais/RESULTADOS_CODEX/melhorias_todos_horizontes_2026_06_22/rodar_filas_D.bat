@echo off
title Filas D - melhorias (8h_alt+4h_alt+12h_alt+8h_conv+12h_conv)
set PYTHONIOENCODING=utf-8
cd /d "D:\PREVINE\redes_neurais\RESULTADOS_CODEX\melhorias_todos_horizontes_2026_06_22"
echo Retomando filas de melhorias D (retoma de onde parou)...
echo Hora: %date% %time%
py rodar_todas_filas_melhorias_D.py
echo Finalizado: %date% %time%
pause
