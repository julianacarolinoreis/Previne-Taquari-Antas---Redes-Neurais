function [wh,bh,ws,bs,J,EQ,EV,TX,DE]=Retroprvcfn2(pt,tt,ptv,ttv,Ah,Dh,As,Ds,nh,Cic,Prc,Mom)

%ALGORITMO RETROPROPAGATIVO PARA TREINAMENTO DE REDES NEURAIS ARTIFICIAIS
    %COM VALIDA��O CRUZADA.
%CRIADO POR GUILHERME GARCIA DE OLIVEIRA
%�LTIMA ATUALIZA��O: QUINTA-FEIRA, 09 DE DEZEMBRO DE 2010, �S 11h15min.
%
%DESCRI��O:
%
%APLICA��O: Redes com ativa��es uniformes em cada camada, sendo "h" a camada intermedi�ria, e "s" a de sa�da. 
%
%PAR�METROS DE ENTRADA:
%pt = Amostras para treinamento transformadas, cada linha um atributo, cada coluna uma amostra.
%tt = Sa�das das amostras de treinamento transformadas, cada linha um atributo, cada coluna uma amostra.
%ptv = Amostras para valida��o transformadas, cada linha um atributo, cada coluna uma amostra.
%ttv = Sa�das das amostras de valida��o transformadas, cada linha um atributo, cada coluna uma amostra.
%Ah, Dh, As, Ds = "inlines" das ativa��es e respectivas derivadas, das camadas h e s, respectivamente.
%nh = N�mero de neur�nios na camada intermedi�ria.
%Cic = N�mero m�ximo de ciclos do procedimento iterativo.
%Prc = Aproxima��o aceit�vel para o maior erro absoluto em um ciclo. 
%Mom = Termo de in�rcia.
%
%RESULTADOS:
%wh,bh,ws,bs = Pesos sin�pticos finais.
%EQ,EV,TX,DE = Vetores com as ra�zes dos erros quadr�ticos m�dios (treinamento e valida��o), as taxas de aprendizado e as m�dias das derivadas das fun��es de ativa��o.
%J = n�mero de ciclos para obten��o do melhor resultado
%

%Defini��es e Inicializa��es:
[natr,nexe]=size(pt); nneu=size(tt,1); [wh,bh,ws,bs]=iniciaisfn(nh,pt,tt); U=ones(1,nexe);
taxa=0.01; ciclo=1; TX=zeros(1,Cic); ME=zeros(1,Cic); DE=zeros(1,Cic);
h=wh*pt+bh*U; a=As(ws*h+bs*U); ME(ciclo)=mean(mean(abs(tt-a))); TX(ciclo)=taxa; e=tt-a;

%Treinamento:
[dwh,dbh,dws,dbs]=deal(zeros(size(wh)),zeros(size(bh)),zeros(size(ws)),zeros(size(bs)));
Dc=ones(1,size(ttv,2)); ec=ttv-As(ws*Ah(wh*ptv+bh*Dc)+bs*Dc); ec2=ec.^2; 
EX=((sum(sum(ec2)))/(size(ec2,2)))^0.5;
    while max(abs(e)')'>=Prc, ciclo=ciclo+1;
        if ciclo>=Cic,
            break,
        end
    
    %Atualiza��o dos pesos sin�pticos:
    [Wh,Bh,Ws,Bs,De]=atualizafn(wh,bh,ws,bs,pt,h,a,e,Dh,Ds,taxa,U);
    [Wh,Bh,Ws,Bs]=deal(Wh+Mom.*dwh,Bh+Mom.*dbh,Ws+Mom.*dws,Bs+Mom.*dbs);

    %Julgamento dos novos pesos e atualiza��o da taxa heur�stica:
    H=Ah(Wh*pt+Bh*U); A=As(Ws*H+Bs*U); E=tt-A; E2=E.^2;
    %close all, %plot(tt,'b'), hold on, plot (A,'k'), hold on,
    %plot(E,'r'), EABS=abs(E); ERRO_MEDIO=mean(mean(EABS)), pause(3), 
    EQ(ciclo)=((sum(sum(E2)))/(size(E,2)))^0.5; DE(ciclo)=De; TX(ciclo)=taxa;
        if EQ(ciclo)<=EQ(ciclo-1)
        [dwh,dbh,dws,dbs]=deal(Wh-wh,Bh-bh,Ws-ws,Bs-bs);
        [wh,bh,ws,bs,h,a,e,taxa]=deal(Wh,Bh,Ws,Bs,H,A,E,taxa*1.1);
        else
        taxa=max(taxa*0.5,0.01);
        end
        if max(abs(e)')'<=Prc,
            break,
        end
        
    %Estat�sticas de valida��o :
    ec=ttv-As(Ws*Ah(Wh*ptv+Bh*Dc)+Bs*Dc); ec2=ec.^2; EV(ciclo)=((sum(sum(ec2)))/(size(ec2,2)))^0.5;
        if EV(ciclo)<EX, EX=EV(ciclo);
        [Wx,Bx,Wy,By,J]=deal(Wh,Bh,Ws,Bs,ciclo);
        end
    end
DE(1)=DE(2); EQ=nonzeros(EQ)';TX=nonzeros(TX)';DE=nonzeros(DE)'; EV=nonzeros(EV)'; DE=DE./nneu;
[wh,bh,ws,bs]=deal(Wx,Bx,Wy,By);
return

function [wh,bh,ws,bs]=iniciaisfn(nh,pt,tt)
%[wh,bh,ws,bs] = iniciaisfn(nh,pt,tt)
% Inicializa��o dos pesos sin�pticos de uma rede de uma ou duas camadas.
    
    if (nargin>=2)&(nargout==2)
        natr=size(pt,1); pmax=max(max(abs(pt)));
        wh=(rand(nh,natr).*2-1)./(natr*pmax); bh=(rand(nh,1).*2-1)./(natr*pmax);
    elseif (nargin==3)&(nargout==4)
        natr=size(pt,1); pmax=max(max(abs(pt))); ns=size(tt,1);
        wh=(rand(nh,natr).*2-1)./(natr*pmax); bh=(rand(nh,1).*2-1)./(natr*pmax);
        ws=(rand(ns,nh).*2-1)./(nh); bs=(rand(ns,1).*2-1)./(nh);
    else
        error('Acionamento incorreto da fun��o!')
    end
return

function [Wh,Bh,Ws,Bs,De]=atualizafn(wh,bh,ws,bs,pt,h,a,e,Dh,Ds,taxa,U)
%[Wh,Bh,Ws,Bs,De]=atualizafn(wh,bh,ws,bs,pt,h,a,e,Dh,Ds,taxa,U)
% Atualiza��o dos pesos sin�pticos de uma rede neural artificial.

derivada_s=Ds(a); derivada_h=Dh(h); delta_s=e.*derivada_s; delta_h=(ws'*delta_s).*derivada_h;
Ws=ws+taxa*delta_s*h'; Bs=bs+taxa*delta_s*U'; Wh=wh+taxa*delta_h*pt'; Bh=bh+taxa*delta_h*U';
De=sum(sum(derivada_s))+sum(sum(derivada_h));
return