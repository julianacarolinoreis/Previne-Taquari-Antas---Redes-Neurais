﻿$testDir = 'D:\PREVINE\redes_neurais\RESULTADOS_CODEX\teste_pontual_8h_alt_ajuste_2026_06_23'
$matlab = 'C:\Program Files\MATLAB\R2014a\bin\matlab.exe'
$excel = (Join-Path $testDir '01_8h_alt_local_st_ant_itui_AJUSTADO_RETREINO_nh6_nit10_cic240000.xlsx').Replace('\','/')
$mat = (Join-Path $testDir 'mdl_retreino_ajustado_local_st_ant_itui_nh6_nit10_cic240000.mat').Replace('\','/')
$csv = (Join-Path $testDir 'resultado_retreino_ajustado_cic240000.csv').Replace('\','/')
$log = Join-Path $testDir 'log_retreino_ajustado_cic240000_matlab.txt'
$status = Join-Path $testDir 'status_retreino_cic240000.json'
@{state='running'; started_at=(Get-Date).ToString('s'); current='nh6 nit10 Cic240000'; csv=$csv; log=$log} | ConvertTo-Json | Set-Content -LiteralPath $status -Encoding UTF8
$cmd = "try; cd('$($testDir.Replace('\','/'))'); EXCEL='$excel'; PLAN='AUDITORIA'; input=5; faixaEntrada='L2:P672'; faixaSaida='R2:R672'; SERIE='J2:J672'; CEL='T2:T672'; nh=6; nit=10; Cic=240000; file='$mat'; arquivoCSV='$csv'; gravarExcel=1; modelo_autoalt; catch ME; disp(getReport(ME,'extended')); exit(1); end; exit;"
& $matlab -wait -nosplash -nodesktop -logfile $log -r $cmd
$exit=$LASTEXITCODE
@{state=($(if($exit -eq 0){'complete'}else{'error'})); exit_code=$exit; finished_at=(Get-Date).ToString('s'); current='nh6 nit10 Cic240000'; csv=$csv; log=$log} | ConvertTo-Json | Set-Content -LiteralPath $status -Encoding UTF8
