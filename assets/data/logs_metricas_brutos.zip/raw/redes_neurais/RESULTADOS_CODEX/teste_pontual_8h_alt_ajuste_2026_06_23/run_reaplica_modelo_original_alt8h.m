clear
close all
clc

baseDir = 'D:/PREVINE/redes_neurais/RESULTADOS_CODEX/teste_pontual_8h_alt_ajuste_2026_06_23';
EXCEL = [baseDir '/01_8h_alt_local_st_ant_itui_AJUSTADO_REAPLICA_MODELO_ORIGINAL.xlsx'];
PLAN = 'AUDITORIA';
modeloFile = [baseDir '/modelo_original_0739.mat'];
arquivoCSV = [baseDir '/resultado_reaplica_modelo_original.csv'];

input = 5;
faixaEntrada = 'L2:P672';
faixaSaida = 'R2:R672';
SERIE = 'J2:J672';
CEL = 'T2:T672';

disp('Reaplicando modelo original nos inputs ajustados...')

DADOS = [];
DADOS(:,1:input) = xlsread(EXCEL, PLAN, faixaEntrada);
DADOS(:,input+1) = xlsread(EXCEL, PLAN, faixaSaida);
X = xlsread(EXCEL, PLAN, SERIE);

load(modeloFile)

unisig = inline('1./(1+exp(-n))');
esclin = inline('(v-b*u)./(a*u)','v','a','b','u');
reclin = inline('(a*u).*s+b*u','s','a','b','u');
As = unisig;
Ah = unisig;

Ptot = DADOS(:,1:input)';
Ttot = DADOS(:,input+1:end)';
Utot = ones(1,size(Ptot,2));
ptot = esclin(Ptot,ae,be,Utot);

ATUAL_TOT = DADOS(:,1)';
Tctot1 = reclin(As(ws*Ah(wh*ptot+bh*Utot)+bs*Utot),au,bu,Utot) + ATUAL_TOT;
Tv1 = Ttot + ATUAL_TOT;

rnaout = Tctot1';
[status,msg] = xlswrite(EXCEL,rnaout,PLAN,CEL);
if status ~= 1
    disp('Falha ao escrever RNA no Excel:')
    disp(msg.message)
end

idxTeste = find(X==3)';
idxVal = find(X==2)';

e2 = (Tv1-Tctot1).^2;
erroAbs = abs(Tv1-Tctot1);

pers = 1 - sum(e2(idxTeste)) / sum((Tv1(idxTeste)-ATUAL_TOT(idxTeste)).^2);
nash = 1 - sum(e2(idxTeste)) / sum((Tv1(idxTeste)-mean(Tv1(idxTeste))).^2);
nashVal = 1 - sum(e2(idxVal)) / sum((Tv1(idxVal)-mean(Tv1(idxVal))).^2);
cc = corrcoef(Tctot1(idxTeste),Tv1(idxTeste));
mae = mean(erroAbs(idxTeste));
e95 = prctile(erroAbs(idxTeste),95);

fid = fopen(arquivoCSV,'w');
fprintf(fid,'MODO;N_TESTE;N_VALIDACAO;NASH_VAL;NASH_TESTE;PERS;CORRELACAO;MAE_CM;E95_CM;MODELO;EXCEL\n');
fprintf(fid,'REAPLICA_MODELO_ORIGINAL;%d;%d;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%s;%s\n', ...
    length(idxTeste), length(idxVal), nashVal, nash, pers, cc(1,2), mae, e95, modeloFile, EXCEL);
fclose(fid);

disp('Resultado reaplicacao:')
disp(['N_TESTE = ' num2str(length(idxTeste))])
disp(['NASH_VAL = ' num2str(nashVal)])
disp(['NASH_TESTE = ' num2str(nash)])
disp(['PERS = ' num2str(pers)])
disp(['CORRELACAO = ' num2str(cc(1,2))])
disp(['MAE_CM = ' num2str(mae)])
disp(['E95_CM = ' num2str(e95)])
