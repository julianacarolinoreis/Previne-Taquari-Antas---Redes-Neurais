$ErrorActionPreference = 'Stop'
$baseDir = 'D:\PREVINE\redes_neurais\RESULTADOS_CODEX\rodada_8h_alt_sem_inp04_melhorias_2026_06_24'
$matlab = 'C:\Program Files\MATLAB\R2014a\bin\matlab.exe'
$excel = 'D:\PREVINE\redes_neurais\RESULTADOS_CODEX\rodada_8h_alt_sem_inp04_melhorias_2026_06_24\teste_sem_inp04_melhorias_8h_alt.xlsx'.Replace('\\','/')
$csv = (Join-Path $baseDir 'resultados_8h_alt_sem_inp04_melhorias.csv').Replace('\\','/')
$status = Join-Path $baseDir 'status_rodada_8h_alt_sem_inp04_melhorias.json'
$controle = Join-Path $baseDir 'controle_execucao_8h_alt_sem_inp04_melhorias.csv'
"PLAN;state;started_at;finished_at;exit_code;log;mat" | Set-Content -LiteralPath $controle -Encoding UTF8
@{state='running'; started_at=(Get-Date).ToString('s'); current='iniciando'; excel=$excel; csv=$csv; baseDir=$baseDir} | ConvertTo-Json | Set-Content -LiteralPath $status -Encoding UTF8
$configs = @(
    @{PLAN='BASE_sem_inp04'; input=13; faixaEntrada='I3:U1520'; faixaSaida='V3:V1520'; SERIE='H3:H1520'; CEL='W3:W1520'; nh=21; nit=5; Cic=120000; mat='mdl_BASE_sem_inp04_nh21_nit5_cic120000.mat'; log='log_BASE_sem_inp04_matlab.txt'},
    @{PLAN='FILTRO_BARR_DESC'; input=13; faixaEntrada='I3:U1520'; faixaSaida='V3:V1520'; SERIE='H3:H1520'; CEL='W3:W1520'; nh=21; nit=5; Cic=120000; mat='mdl_FILTRO_BARR_DESC_nh21_nit5_cic120000.mat'; log='log_FILTRO_BARR_DESC_matlab.txt'},
    @{PLAN='SEM_86125500_D11'; input=12; faixaEntrada='I3:T1520'; faixaSaida='U3:U1520'; SERIE='H3:H1520'; CEL='V3:V1520'; nh=21; nit=5; Cic=120000; mat='mdl_SEM_86125500_D11_nh21_nit5_cic120000.mat'; log='log_SEM_86125500_D11_matlab.txt'},
    @{PLAN='SEM_86497400_D13'; input=12; faixaEntrada='I3:T1520'; faixaSaida='U3:U1520'; SERIE='H3:H1520'; CEL='V3:V1520'; nh=21; nit=5; Cic=120000; mat='mdl_SEM_86497400_D13_nh21_nit5_cic120000.mat'; log='log_SEM_86497400_D13_matlab.txt'},
    @{PLAN='SEM_86102000_D13'; input=12; faixaEntrada='I3:T1520'; faixaSaida='U3:U1520'; SERIE='H3:H1520'; CEL='V3:V1520'; nh=21; nit=5; Cic=120000; mat='mdl_SEM_86102000_D13_nh21_nit5_cic120000.mat'; log='log_SEM_86102000_D13_matlab.txt'},
    @{PLAN='SEM_ST_D2'; input=12; faixaEntrada='I3:T1520'; faixaSaida='U3:U1520'; SERIE='H3:H1520'; CEL='V3:V1520'; nh=21; nit=5; Cic=120000; mat='mdl_SEM_ST_D2_nh21_nit5_cic120000.mat'; log='log_SEM_ST_D2_matlab.txt'},
    @{PLAN='FILTRO_SEM_86125500'; input=12; faixaEntrada='I3:T1520'; faixaSaida='U3:U1520'; SERIE='H3:H1520'; CEL='V3:V1520'; nh=21; nit=5; Cic=120000; mat='mdl_FILTRO_SEM_86125500_nh21_nit5_cic120000.mat'; log='log_FILTRO_SEM_86125500_matlab.txt'},
    @{PLAN='FILTRO_SEM_86497400'; input=12; faixaEntrada='I3:T1520'; faixaSaida='U3:U1520'; SERIE='H3:H1520'; CEL='V3:V1520'; nh=21; nit=5; Cic=120000; mat='mdl_FILTRO_SEM_86497400_nh21_nit5_cic120000.mat'; log='log_FILTRO_SEM_86497400_matlab.txt'}
)
foreach ($cfg in $configs) {
    $started = (Get-Date).ToString('s')
    $mat = (Join-Path $baseDir $cfg.mat).Replace('\\','/')
    $log = Join-Path $baseDir $cfg.log
    @{state='running'; started_at=$started; current=$cfg.PLAN; excel=$excel; csv=$csv; log=$log; mat=$mat} | ConvertTo-Json | Set-Content -LiteralPath $status -Encoding UTF8
    $cmd = "try; cd('$($baseDir.Replace('\','/'))'); EXCEL='$excel'; PLAN='$($cfg.PLAN)'; input=$($cfg.input); faixaEntrada='$($cfg.faixaEntrada)'; faixaSaida='$($cfg.faixaSaida)'; SERIE='$($cfg.SERIE)'; CEL='$($cfg.CEL)'; nh=$($cfg.nh); nit=$($cfg.nit); Cic=$($cfg.Cic); file='$mat'; arquivoCSV='$csv'; gravarExcel=1; modelo_autoalt_fila; catch ME; disp(getReport(ME,'extended')); exit(1); end; exit;"
    & $matlab -wait -nosplash -nodesktop -logfile $log -r $cmd
    $exit = $LASTEXITCODE
    $finished = (Get-Date).ToString('s')
    "$($cfg.PLAN);done;$started;$finished;$exit;$log;$mat" | Add-Content -LiteralPath $controle -Encoding UTF8
    if ($exit -ne 0) {
        @{state='error'; exit_code=$exit; finished_at=$finished; current=$cfg.PLAN; excel=$excel; csv=$csv; log=$log; mat=$mat} | ConvertTo-Json | Set-Content -LiteralPath $status -Encoding UTF8
        exit $exit
    }
}
@{state='complete'; finished_at=(Get-Date).ToString('s'); current='todos_concluidos'; excel=$excel; csv=$csv; baseDir=$baseDir} | ConvertTo-Json | Set-Content -LiteralPath $status -Encoding UTF8