try
    root_dir = 'D:\PREVINE\redes_neurais\RESULTADOS_CODEX\teste_pontual_8h_alt_core_fisico_2026_06_23';
    cd(root_dir);
    EXCEL = fullfile(root_dir, 'matlab_input_core_fisico.xlsx');
    PLAN = 'RNA_CORE_FISICO_8H';
    input = 12;
    faixaEntrada = 'I3:T1424';
    faixaSaida = 'U3:U1424';
    CEL = 'W3';
    SERIE = 'H3:H1424';
    nh = 8;
    nit = 20;
    Cic = 80000;
    file = fullfile(root_dir, 'RNA_CORE_FISICO_8H_MINIMAL_nh8_nit20_cic80000.mat');
    arquivoCSV = fullfile(root_dir, 'resultado_core_fisico_minimal.csv');
    gravarExcel = 1;
    modelo_autoalt;
catch ME
    disp('ERRO_CONTROLADO_RUN_CORE_FISICO_MINIMAL')
    disp(getReport(ME, 'extended'))
end
exit
