@echo off
title 2h_conv - Retomada planos 10-12
cd /d "D:\PREVINE\redes_neurais\RNA_2H_CONV_MODELO_AUTO_2026_06_24\codigos"
echo Iniciando retomada 2h_conv - planos 10, 11, 12...
echo Hora: %date% %time%
"C:\Program Files\MATLAB\R2014a\bin\matlab.exe" -nosplash -r "cd('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos'); run_remaining_2h_conv"
echo Finalizado: %date% %time%
pause
