% run_remaining_2h_conv.m
% Retomada a partir do plano 10/12 (22, 23, 24)
% Nao apaga resultados existentes - apenas APENDA ao CSV e log

resultCsv = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/resultados_modelo_auto_2h_conv_sem_xlswrite.csv';
statusCsv = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/status/status_modelo_auto_2h_conv_sem_xlswrite.csv';
logFile   = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/logs/run_all_2h_conv_sem_xlswrite.log';

diary(logFile);
disp('=== RETOMADA: planos 10-12 (22, 23, 24) ===');
disp(['Inicio retomada: ', datestr(now,'yyyy-mm-dd HH:MM:SS')]);

plans = repmat(struct('name','','excel','','input',0,'nh',0,'faixaEntrada','','faixaSaida','','SERIE','','CEL','','mat','','n_rows',0), 1, 3);

plans(1).name = '22_2h_conv_2H_CONV_C0505';
plans(1).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/22_2h_conv_2H_CONV_C0505.xlsx';
plans(1).input = 10;
plans(1).nh = 20;
plans(1).faixaEntrada = 'K2:T1665';
plans(1).faixaSaida = 'U2:U1665';
plans(1).SERIE = 'B2:B1665';
plans(1).CEL = 'W2:W1665';
plans(1).mat = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/mat/22_2h_conv_2H_CONV_C0505.mat';
plans(1).n_rows = 1664;

plans(2).name = '23_2h_conv_2H_CONV_C0098';
plans(2).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/23_2h_conv_2H_CONV_C0098.xlsx';
plans(2).input = 11;
plans(2).nh = 22;
plans(2).faixaEntrada = 'K2:U2618';
plans(2).faixaSaida = 'V2:V2618';
plans(2).SERIE = 'B2:B2618';
plans(2).CEL = 'X2:X2618';
plans(2).mat = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/mat/23_2h_conv_2H_CONV_C0098.mat';
plans(2).n_rows = 2617;

plans(3).name = '24_2h_conv_2H_CONV_C1145';
plans(3).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/24_2h_conv_2H_CONV_C1145.xlsx';
plans(3).input = 14;
plans(3).nh = 28;
plans(3).faixaEntrada = 'K2:X1667';
plans(3).faixaSaida = 'Y2:Y1667';
plans(3).SERIE = 'B2:B1667';
plans(3).CEL = 'AA2:AA1667';
plans(3).mat = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/mat/24_2h_conv_2H_CONV_C1145.mat';
plans(3).n_rows = 1666;

for k = 1:length(plans)
    ordem = k + 9;  % planos 10, 11, 12 na numeracao original
    inicio = datestr(now, 'yyyy-mm-dd HH:MM:SS');
    fprintf('\n==== %d/12 %s ====\n', ordem, plans(k).name);
    fid = fopen(statusCsv, 'a');
    fprintf(fid, '%d;%s;%s;%s;%s;%s\n', ordem, plans(k).name, 'INICIADO', inicio, '', '');
    fclose(fid);
    try
        EXCEL = plans(k).excel; PLAN = 'DADOS'; input = plans(k).input;
        faixaEntrada = plans(k).faixaEntrada; faixaSaida = plans(k).faixaSaida;
        CEL = plans(k).CEL; SERIE = plans(k).SERIE; nh = plans(k).nh;
        nit = 10; Cic = 100000; file = plans(k).mat;
        gravarExcel = 0; arquivoCSV = resultCsv;
        run_one_auto(EXCEL, PLAN, input, faixaEntrada, faixaSaida, CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV);
        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        fid = fopen(statusCsv, 'a');
        fprintf(fid, '%d;%s;%s;%s;%s;%s\n', ordem, plans(k).name, 'CONCLUIDO', inicio, fim, '');
        fclose(fid);
    catch ME
        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        msg = strrep(ME.message, ';', ',');
        msg = strrep(msg, sprintf('\n'), ' ');
        fid = fopen(statusCsv, 'a');
        fprintf(fid, '%d;%s;%s;%s;%s;%s\n', ordem, plans(k).name, 'ERRO', inicio, fim, msg);
        fclose(fid);
        disp(getReport(ME));
    end
end

disp('=== Retomada 2h_conv finalizada ===');
diary off;
exit;
