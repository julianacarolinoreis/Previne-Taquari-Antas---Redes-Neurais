function run_one_auto(EXCEL, PLAN, input, faixaEntrada, faixaSaida, CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV)
% Wrapper para preservar o loop externo apesar do clearvars dentro do modelo_auto.m.
modelo_auto;
end
