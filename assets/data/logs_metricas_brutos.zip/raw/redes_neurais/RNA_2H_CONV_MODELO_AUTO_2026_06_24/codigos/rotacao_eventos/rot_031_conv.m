clear; clc;
% Rotação 031: TESTE=evt7(abr24a), VALIDACAO=evt12(set24), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [7];
evt_valida = [12];
run_all_rotacao_conv('rot_031', evt_teste, evt_valida);
exit;
