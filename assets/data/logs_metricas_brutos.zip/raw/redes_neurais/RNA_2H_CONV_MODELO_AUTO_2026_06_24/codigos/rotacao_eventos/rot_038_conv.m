clear; clc;
% Rotação 038: TESTE=evt12(set24), VALIDACAO=evt2(jun23), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [12];
evt_valida = [2];
run_all_rotacao_conv('rot_038', evt_teste, evt_valida);
exit;
