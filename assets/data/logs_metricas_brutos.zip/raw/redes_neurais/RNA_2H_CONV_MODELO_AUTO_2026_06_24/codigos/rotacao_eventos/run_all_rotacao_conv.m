function run_all_rotacao_conv(rot_id, evt_teste, evt_valida)
% Roda todos os 12 modelos CONV com a rotacao de eventos especificada.
% rot_id   : string ex. 'rot_001'
% evt_teste : array de IDs de evento para TESTE    (serie=3)
% evt_valida: array de IDs de evento para VALIDACAO (serie=2)
% Fixos sempre Treino: 4 (set/23), 5 (nov/23), 7 (abr/24), 8 (abr-mai/24)

rotDir     = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/rotacao';
resultCsv  = [rotDir '/resultados/' rot_id '_conv.csv'];
statusCsv  = [rotDir '/status/'     rot_id '_conv_status.csv'];
logFile    = [rotDir '/logs/'       rot_id '_conv.log'];
matDir     = [rotDir '/mat'];

diary(logFile);
fprintf('\n====== Rotacao %s | CONV | teste=%s valida=%s ======\n', rot_id, num2str(evt_teste), num2str(evt_valida));
fid=fopen(statusCsv,'w'); fprintf(fid,'ordem;planilha;status;inicio;fim;mensagem\n'); fclose(fid);

plans = repmat(struct('name','','excel','','input',0,'nh',0,'faixaEntrada','','faixaSaida','','SERIE','','CEL',''), 1, 12);
plans(1).name = '13_2h_conv_2H_CONV_C0001';
plans(1).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/13_2h_conv_2H_CONV_C0001.xlsx';
plans(1).input = 7;
plans(1).nh = 14;
plans(1).faixaEntrada = 'K2:Q2820';
plans(1).faixaSaida = 'R2:R2820';
plans(1).SERIE = 'B2:B2820';
plans(1).CEL = 'T2:T2820';
plans(2).name = '14_2h_conv_2H_CONV_C0009';
plans(2).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/14_2h_conv_2H_CONV_C0009.xlsx';
plans(2).input = 7;
plans(2).nh = 14;
plans(2).faixaEntrada = 'K2:Q2801';
plans(2).faixaSaida = 'R2:R2801';
plans(2).SERIE = 'B2:B2801';
plans(2).CEL = 'T2:T2801';
plans(3).name = '15_2h_conv_2H_CONV_C0017';
plans(3).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/15_2h_conv_2H_CONV_C0017.xlsx';
plans(3).input = 7;
plans(3).nh = 14;
plans(3).faixaEntrada = 'K2:Q2788';
plans(3).faixaSaida = 'R2:R2788';
plans(3).SERIE = 'B2:B2788';
plans(3).CEL = 'T2:T2788';
plans(4).name = '16_2h_conv_2H_CONV_C0785';
plans(4).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/16_2h_conv_2H_CONV_C0785.xlsx';
plans(4).input = 9;
plans(4).nh = 18;
plans(4).faixaEntrada = 'K2:S1778';
plans(4).faixaSaida = 'T2:T1778';
plans(4).SERIE = 'B2:B1778';
plans(4).CEL = 'V2:V1778';
plans(5).name = '17_2h_conv_2H_CONV_C0793';
plans(5).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/17_2h_conv_2H_CONV_C0793.xlsx';
plans(5).input = 9;
plans(5).nh = 18;
plans(5).faixaEntrada = 'K2:S1764';
plans(5).faixaSaida = 'T2:T1764';
plans(5).SERIE = 'B2:B1764';
plans(5).CEL = 'V2:V1764';
plans(6).name = '18_2h_conv_2H_CONV_C0393';
plans(6).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/18_2h_conv_2H_CONV_C0393.xlsx';
plans(6).input = 8;
plans(6).nh = 16;
plans(6).faixaEntrada = 'K2:R1778';
plans(6).faixaSaida = 'S2:S1778';
plans(6).SERIE = 'B2:B1778';
plans(6).CEL = 'U2:U1778';
plans(7).name = '19_2h_conv_2H_CONV_C0897';
plans(7).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/19_2h_conv_2H_CONV_C0897.xlsx';
plans(7).input = 11;
plans(7).nh = 22;
plans(7).faixaEntrada = 'K2:U1665';
plans(7).faixaSaida = 'V2:V1665';
plans(7).SERIE = 'B2:B1665';
plans(7).CEL = 'X2:X1665';
plans(8).name = '20_2h_conv_2H_CONV_C0497';
plans(8).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/20_2h_conv_2H_CONV_C0497.xlsx';
plans(8).input = 10;
plans(8).nh = 20;
plans(8).faixaEntrada = 'K2:T1673';
plans(8).faixaSaida = 'U2:U1673';
plans(8).SERIE = 'B2:B1673';
plans(8).CEL = 'W2:W1673';
plans(9).name = '21_2h_conv_2H_CONV_C0361';
plans(9).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/21_2h_conv_2H_CONV_C0361.xlsx';
plans(9).input = 12;
plans(9).nh = 24;
plans(9).faixaEntrada = 'K2:V2583';
plans(9).faixaSaida = 'W2:W2583';
plans(9).SERIE = 'B2:B2583';
plans(9).CEL = 'Y2:Y2583';
plans(10).name = '22_2h_conv_2H_CONV_C0505';
plans(10).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/22_2h_conv_2H_CONV_C0505.xlsx';
plans(10).input = 10;
plans(10).nh = 20;
plans(10).faixaEntrada = 'K2:T1665';
plans(10).faixaSaida = 'U2:U1665';
plans(10).SERIE = 'B2:B1665';
plans(10).CEL = 'W2:W1665';
plans(11).name = '23_2h_conv_2H_CONV_C0098';
plans(11).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/23_2h_conv_2H_CONV_C0098.xlsx';
plans(11).input = 11;
plans(11).nh = 22;
plans(11).faixaEntrada = 'K2:U2618';
plans(11).faixaSaida = 'V2:V2618';
plans(11).SERIE = 'B2:B2618';
plans(11).CEL = 'X2:X2618';
plans(12).name = '24_2h_conv_2H_CONV_C1145';
plans(12).excel = 'D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/planilhas/24_2h_conv_2H_CONV_C1145.xlsx';
plans(12).input = 14;
plans(12).nh = 28;
plans(12).faixaEntrada = 'K2:X1667';
plans(12).faixaSaida = 'Y2:Y1667';
plans(12).SERIE = 'B2:B1667';
plans(12).CEL = 'AA2:AA1667';

for k=1:length(plans)
    inicio = datestr(now, 'yyyy-mm-dd HH:MM:SS');
    fprintf('\n-- %d/12 %s --\n', k, plans(k).name);
    fid=fopen(statusCsv,'a'); fprintf(fid,'%d;%s;%s;%s;%s;%s\n', k, plans(k).name, 'INICIADO', inicio, '', ''); fclose(fid);
    try
        EXCEL = plans(k).excel;
        PLAN  = 'DADOS';
        input = plans(k).input;
        faixaEntrada = plans(k).faixaEntrada;
        faixaSaida   = plans(k).faixaSaida;
        CEL   = plans(k).CEL;
        SERIE = plans(k).SERIE;
        nh    = plans(k).nh;
        nit   = 10;
        Cic   = 100000;
        file  = [matDir '/' rot_id '_' plans(k).name '.mat'];
        gravarExcel = 0;
        arquivoCSV  = resultCsv;
        run_one_auto_rot(EXCEL, PLAN, input, faixaEntrada, faixaSaida, CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV, evt_teste, evt_valida);
        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        fid=fopen(statusCsv,'a'); fprintf(fid,'%d;%s;%s;%s;%s;%s\n', k, plans(k).name, 'CONCLUIDO', inicio, fim, ''); fclose(fid);
    catch ME
        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        msg = strrep(ME.message, ';', ',');
        msg = strrep(msg, sprintf('\n'), ' ');
        fid=fopen(statusCsv,'a'); fprintf(fid,'%d;%s;%s;%s;%s;%s\n', k, plans(k).name, 'ERRO', inicio, fim, msg); fclose(fid);
        disp(getReport(ME));
    end
end
fprintf('Rotacao %s CONV finalizada.\n', rot_id);
diary off;
end
