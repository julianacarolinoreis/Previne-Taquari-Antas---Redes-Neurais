clear; clc;
% Rotação 075: TESTE=evt19(ago25), VALIDACAO=evt3(jul23), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [19];
evt_valida = [3];
run_all_rotacao_conv('rot_075', evt_teste, evt_valida);
exit;
