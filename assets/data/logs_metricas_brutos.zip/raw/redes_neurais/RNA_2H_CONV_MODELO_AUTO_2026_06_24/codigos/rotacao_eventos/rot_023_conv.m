clear; clc;
% Rotação 023: TESTE=evt3(jul23), VALIDACAO=evt13(dez24a), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [3];
evt_valida = [13];
run_all_rotacao_conv('rot_023', evt_teste, evt_valida);
exit;
