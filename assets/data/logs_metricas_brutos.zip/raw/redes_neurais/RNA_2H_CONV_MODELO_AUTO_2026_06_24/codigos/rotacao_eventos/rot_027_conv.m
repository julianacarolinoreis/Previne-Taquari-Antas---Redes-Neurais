clear; clc;
% Rotação 027: TESTE=evt3(jul23), VALIDACAO=evt20(set25), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [3];
evt_valida = [20];
run_all_rotacao_conv('rot_027', evt_teste, evt_valida);
exit;
