clear; clc;
% Rotação 063: TESTE=evt14(dez24b), VALIDACAO=evt20(set25), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [14];
evt_valida = [20];
run_all_rotacao_conv('rot_063', evt_teste, evt_valida);
exit;
