clear; clc;
% Rotação 087: TESTE=evt20(set25), VALIDACAO=evt13(dez24a), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [20];
evt_valida = [13];
run_all_rotacao_conv('rot_087', evt_teste, evt_valida);
exit;
