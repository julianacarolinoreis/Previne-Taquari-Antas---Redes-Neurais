clear; clc;
% Rotação 021: TESTE=evt3(jul23), VALIDACAO=evt7(abr24a), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [3];
evt_valida = [7];
run_all_rotacao_conv('rot_021', evt_teste, evt_valida);
exit;
