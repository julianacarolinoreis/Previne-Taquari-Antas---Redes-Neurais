clear; clc;
% Rotação 019: TESTE=evt3(jul23), VALIDACAO=evt1(mai23), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [3];
evt_valida = [1];
run_all_rotacao_conv('rot_019', evt_teste, evt_valida);
exit;
