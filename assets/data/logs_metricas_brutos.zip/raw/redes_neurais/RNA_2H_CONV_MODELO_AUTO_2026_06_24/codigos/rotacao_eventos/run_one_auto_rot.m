function run_one_auto_rot(EXCEL, PLAN, input, faixaEntrada, faixaSaida, CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV, evt_teste, evt_valida)
% Wrapper para rotacao de eventos (CONV) - preserva loop externo durante clearvars.
modelo_auto_rot;
end
