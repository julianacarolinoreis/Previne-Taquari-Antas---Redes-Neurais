clear; clc;
% Rotação 061: TESTE=evt14(dez24b), VALIDACAO=evt18(jul25), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_CONV_MODELO_AUTO_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [14];
evt_valida = [18];
run_all_rotacao_conv('rot_061', evt_teste, evt_valida);
exit;
