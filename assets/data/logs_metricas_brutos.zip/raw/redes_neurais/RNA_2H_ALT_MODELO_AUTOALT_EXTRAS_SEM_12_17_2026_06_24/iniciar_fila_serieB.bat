@echo off
echo [%DATE% %TIME%] BAT iniciado >> "D:\PREVINE\redes_neurais\RNA_2H_ALT_MODELO_AUTOALT_EXTRAS_SEM_12_17_2026_06_24\bat_debug.log" 2>&1
C:\Users\Usuario\AppData\Local\Python\bin\python.exe "D:\PREVINE\redes_neurais\RNA_2H_ALT_MODELO_AUTOALT_EXTRAS_SEM_12_17_2026_06_24\wait_and_run_serieB.py" >> "D:\PREVINE\redes_neurais\RNA_2H_ALT_MODELO_AUTOALT_EXTRAS_SEM_12_17_2026_06_24\bat_debug.log" 2>&1
echo [%DATE% %TIME%] BAT finalizado (exit=%ERRORLEVEL%) >> "D:\PREVINE\redes_neurais\RNA_2H_ALT_MODELO_AUTOALT_EXTRAS_SEM_12_17_2026_06_24\bat_debug.log" 2>&1
