% Treinamento 2h_alt_extras usando arquivos COMPLETA (12-15 inputs cada)
% Fonte: RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/00_PLANILHAS_COMPLETAS_COM_INPUTS_E_RNA/
clear; clc;

extrasDir = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_EXTRAS_SEM_12_17_2026_06_24';
completaDir = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/00_PLANILHAS_COMPLETAS_COM_INPUTS_E_RNA';

resultCsv = [extrasDir '/resultados_modelo_autoalt_2h_alt_completa.csv'];
statusCsv = [extrasDir '/status/status_modelo_autoalt_2h_alt_completa.csv'];
logFile   = [extrasDir '/logs/run_all_2h_alt_extras_completa.log'];

diary(logFile);
disp('=== Treinamento 2h_alt_extras COMPLETA (12-15 inputs) ===');
disp(datestr(now, 'yyyy-mm-dd HH:MM:SS'));

plans = repmat(struct('name','','excel','','input',0,'nh',0, ...
    'faixaEntrada','','faixaSaida','','SERIE','','CEL','','mat',''), 1, 12);

% --- Plan 1: C0080 — 14 inputs ---
plans(1).name = '01_2h_alt_2H_ALT_C0080';
plans(1).excel = [completaDir '/01_2h_alt_2H_ALT_C0080_COMPLETA_INPUTS_RNA.xlsx'];
plans(1).input = 14; plans(1).nh = 28;
plans(1).faixaEntrada = 'K2:X2867'; plans(1).faixaSaida = 'Y2:Y2867';
plans(1).SERIE = 'B2:B2867'; plans(1).CEL = 'AB2:AB2867';
plans(1).mat = [extrasDir '/mat/01_2h_alt_2H_ALT_C0080.mat'];

% --- Plan 2: C0224 — 14 inputs ---
plans(2).name = '02_2h_alt_2H_ALT_C0224';
plans(2).excel = [completaDir '/02_2h_alt_2H_ALT_C0224_COMPLETA_INPUTS_RNA.xlsx'];
plans(2).input = 14; plans(2).nh = 28;
plans(2).faixaEntrada = 'K2:X2858'; plans(2).faixaSaida = 'Y2:Y2858';
plans(2).SERIE = 'B2:B2858'; plans(2).CEL = 'AB2:AB2858';
plans(2).mat = [extrasDir '/mat/02_2h_alt_2H_ALT_C0224.mat'];

% --- Plan 3: C0079 — 12 inputs ---
plans(3).name = '03_2h_alt_2H_ALT_C0079';
plans(3).excel = [completaDir '/03_2h_alt_2H_ALT_C0079_COMPLETA_INPUTS_RNA.xlsx'];
plans(3).input = 12; plans(3).nh = 24;
plans(3).faixaEntrada = 'K2:V2896'; plans(3).faixaSaida = 'W2:W2896';
plans(3).SERIE = 'B2:B2896'; plans(3).CEL = 'Z2:Z2896';
plans(3).mat = [extrasDir '/mat/03_2h_alt_2H_ALT_C0079.mat'];

% --- Plan 4: C0223 — 12 inputs ---
plans(4).name = '04_2h_alt_2H_ALT_C0223';
plans(4).excel = [completaDir '/04_2h_alt_2H_ALT_C0223_COMPLETA_INPUTS_RNA.xlsx'];
plans(4).input = 12; plans(4).nh = 24;
plans(4).faixaEntrada = 'K2:V2887'; plans(4).faixaSaida = 'W2:W2887';
plans(4).SERIE = 'B2:B2887'; plans(4).CEL = 'Z2:Z2887';
plans(4).mat = [extrasDir '/mat/04_2h_alt_2H_ALT_C0223.mat'];

% --- Plan 5: C0088 — 14 inputs ---
plans(5).name = '05_2h_alt_2H_ALT_C0088';
plans(5).excel = [completaDir '/05_2h_alt_2H_ALT_C0088_COMPLETA_INPUTS_RNA.xlsx'];
plans(5).input = 14; plans(5).nh = 28;
plans(5).faixaEntrada = 'K2:X2849'; plans(5).faixaSaida = 'Y2:Y2849';
plans(5).SERIE = 'B2:B2849'; plans(5).CEL = 'AB2:AB2849';
plans(5).mat = [extrasDir '/mat/05_2h_alt_2H_ALT_C0088.mat'];

% --- Plan 6: C0472 — 15 inputs ---
plans(6).name = '06_2h_alt_2H_ALT_C0472';
plans(6).excel = [completaDir '/06_2h_alt_2H_ALT_C0472_COMPLETA_INPUTS_RNA.xlsx'];
plans(6).input = 15; plans(6).nh = 30;
plans(6).faixaEntrada = 'K2:Y1816'; plans(6).faixaSaida = 'Z2:Z1816';
plans(6).SERIE = 'B2:B1816'; plans(6).CEL = 'AC2:AC1816';
plans(6).mat = [extrasDir '/mat/06_2h_alt_2H_ALT_C0472.mat'];

% --- Plan 7: C0096 — 14 inputs ---
plans(7).name = '07_2h_alt_2H_ALT_C0096';
plans(7).excel = [completaDir '/07_2h_alt_2H_ALT_C0096_COMPLETA_INPUTS_RNA.xlsx'];
plans(7).input = 14; plans(7).nh = 28;
plans(7).faixaEntrada = 'K2:X2836'; plans(7).faixaSaida = 'Y2:Y2836';
plans(7).SERIE = 'B2:B2836'; plans(7).CEL = 'AB2:AB2836';
plans(7).mat = [extrasDir '/mat/07_2h_alt_2H_ALT_C0096.mat'];

% --- Plan 8: C0616 — 15 inputs ---
plans(8).name = '08_2h_alt_2H_ALT_C0616';
plans(8).excel = [completaDir '/08_2h_alt_2H_ALT_C0616_COMPLETA_INPUTS_RNA.xlsx'];
plans(8).input = 15; plans(8).nh = 30;
plans(8).faixaEntrada = 'K2:Y1810'; plans(8).faixaSaida = 'Z2:Z1810';
plans(8).SERIE = 'B2:B1810'; plans(8).CEL = 'AC2:AC1810';
plans(8).mat = [extrasDir '/mat/08_2h_alt_2H_ALT_C0616.mat'];

% --- Plan 9: C0471 — 13 inputs ---
plans(9).name = '09_2h_alt_2H_ALT_C0471';
plans(9).excel = [completaDir '/09_2h_alt_2H_ALT_C0471_COMPLETA_INPUTS_RNA.xlsx'];
plans(9).input = 13; plans(9).nh = 26;
plans(9).faixaEntrada = 'K2:W1844'; plans(9).faixaSaida = 'X2:X1844';
plans(9).SERIE = 'B2:B1844'; plans(9).CEL = 'AA2:AA1844';
plans(9).mat = [extrasDir '/mat/09_2h_alt_2H_ALT_C0471.mat'];

% --- Plan 10: C0087 — 12 inputs ---
plans(10).name = '10_2h_alt_2H_ALT_C0087';
plans(10).excel = [completaDir '/10_2h_alt_2H_ALT_C0087_COMPLETA_INPUTS_RNA.xlsx'];
plans(10).input = 12; plans(10).nh = 24;
plans(10).faixaEntrada = 'K2:V2878'; plans(10).faixaSaida = 'W2:W2878';
plans(10).SERIE = 'B2:B2878'; plans(10).CEL = 'Z2:Z2878';
plans(10).mat = [extrasDir '/mat/10_2h_alt_2H_ALT_C0087.mat'];

% --- Plan 11: C0615 — 13 inputs ---
plans(11).name = '11_2h_alt_2H_ALT_C0615';
plans(11).excel = [completaDir '/11_2h_alt_2H_ALT_C0615_COMPLETA_INPUTS_RNA.xlsx'];
plans(11).input = 13; plans(11).nh = 26;
plans(11).faixaEntrada = 'K2:W1838'; plans(11).faixaSaida = 'X2:X1838';
plans(11).SERIE = 'B2:B1838'; plans(11).CEL = 'AA2:AA1838';
plans(11).mat = [extrasDir '/mat/11_2h_alt_2H_ALT_C0615.mat'];

% --- Plan 12: C0095 — 12 inputs ---
plans(12).name = '12_2h_alt_2H_ALT_C0095';
plans(12).excel = [completaDir '/12_2h_alt_2H_ALT_C0095_COMPLETA_INPUTS_RNA.xlsx'];
plans(12).input = 12; plans(12).nh = 24;
plans(12).faixaEntrada = 'K2:V2864'; plans(12).faixaSaida = 'W2:W2864';
plans(12).SERIE = 'B2:B2864'; plans(12).CEL = 'Z2:Z2864';
plans(12).mat = [extrasDir '/mat/12_2h_alt_2H_ALT_C0095.mat'];

% --- Loop ---
for k = 1:12
    % Skip se mat já existe
    if exist(plans(k).mat, 'file')
        fprintf('\n[SKIP] %d/12 %s — mat já existe\n', k, plans(k).name);
        continue;
    end

    inicio = datestr(now, 'yyyy-mm-dd HH:MM:SS');
    fprintf('\n==== %d/12 %s ====\n', k, plans(k).name);
    fid = fopen(statusCsv, 'a');
    fprintf(fid, '%d;%s;%s;%s;%s;%s\n', k, plans(k).name, 'INICIADO', inicio, '', '');
    fclose(fid);

    try
        EXCEL        = plans(k).excel;
        PLAN         = 'DADOS';
        input        = plans(k).input;
        faixaEntrada = plans(k).faixaEntrada;
        faixaSaida   = plans(k).faixaSaida;
        CEL          = plans(k).CEL;
        SERIE        = plans(k).SERIE;
        nh           = plans(k).nh;
        nit          = 10;
        Cic          = 100000;
        file         = plans(k).mat;
        gravarExcel  = 1;
        arquivoCSV   = resultCsv;

        run_one_autoalt(EXCEL, PLAN, input, faixaEntrada, faixaSaida, ...
            CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV);

        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        fid = fopen(statusCsv, 'a');
        fprintf(fid, '%d;%s;%s;%s;%s;%s\n', k, plans(k).name, 'CONCLUIDO', inicio, fim, '');
        fclose(fid);

    catch ME
        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        msg = strrep(ME.message, ';', ',');
        msg = strrep(msg, sprintf('\n'), ' ');
        fid = fopen(statusCsv, 'a');
        fprintf(fid, '%d;%s;%s;%s;%s;%s\n', k, plans(k).name, 'ERRO', inicio, fim, msg);
        fclose(fid);
        disp(getReport(ME));
    end
end

disp('=== Treinamento 2h_alt_extras COMPLETA finalizado ===');
disp(datestr(now, 'yyyy-mm-dd HH:MM:SS'));

% Gerar RESULTADO_AUDITAVEL para cada plano
disp('Gerando arquivos RESULTADO_AUDITAVEL...');
completaDir2 = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/00_PLANILHAS_COMPLETAS_COM_INPUTS_E_RNA';
matDir2      = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_EXTRAS_SEM_12_17_2026_06_24/mat';
outDir2      = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_EXTRAS_SEM_12_17_2026_06_24/resultados_excel_auditaveis';
cmd2 = ['python "D:/PREVINE/redes_neurais/gerar_resultados_auditaveis.py" ' ...
        '"' completaDir2 '" "' matDir2 '" "' outDir2 '"' ...
        ' > "D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_EXTRAS_SEM_12_17_2026_06_24/logs/auditaveis_log.txt" 2>&1'];
system(cmd2);
disp('RESULTADO_AUDITAVEL gerados.');

diary off;
exit;
