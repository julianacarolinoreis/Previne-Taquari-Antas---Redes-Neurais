@echo off
title 2h_alt_extras - 12 planos
cd /d "D:\PREVINE\redes_neurais\RNA_2H_ALT_MODELO_AUTOALT_EXTRAS_SEM_12_17_2026_06_24\codigos"
echo Iniciando 2h_alt_extras (12 planos)...
echo Hora: %date% %time%
"C:\Program Files\MATLAB\R2014a\bin\matlab.exe" -nosplash -r "cd('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_EXTRAS_SEM_12_17_2026_06_24/codigos'); run_all_2h_alt"
echo Finalizado: %date% %time%
pause
