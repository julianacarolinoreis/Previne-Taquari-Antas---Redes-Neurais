function run_one_auto_rot2h(EXCEL, PLAN, input, faixaEntrada, faixaSaida, CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV, rot_id, evt_teste, evt_valida, tipo, modelo_nome)
modelo_auto_rot2h;
end
