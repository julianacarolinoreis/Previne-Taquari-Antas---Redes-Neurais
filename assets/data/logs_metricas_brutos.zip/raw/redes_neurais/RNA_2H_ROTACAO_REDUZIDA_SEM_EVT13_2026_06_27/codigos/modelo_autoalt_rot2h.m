% SCRIPT PARA PREVISAO DE SERIE TEMPORAL COM REDES NEURAIS ARTIFICIAIS:
% MODELO RNA ALTER 4H / D4H

clearvars -except PLAN input EXCEL CEL SERIE faixaEntrada faixaSaida nh nit Cic file gravarExcel arquivoCSV rot_id evt_teste evt_valida tipo modelo_nome
close all
clc
tic

disp('Carregando dados... MODELO RNA ALTER 4H / D4H')

if ~exist('EXCEL','var'), EXCEL='teste1alt4h.xlsx'; end
if ~exist('PLAN','var'), PLAN='Planilha2'; end
if ~exist('input','var'), input=14; end
if ~exist('faixaEntrada','var'), faixaEntrada='I3:V1594'; end
if ~exist('faixaSaida','var'), faixaSaida='W3:W1594'; end
if ~exist('CEL','var'), CEL='Y3:Y1594'; end
if ~exist('SERIE','var'), SERIE='AD3:AD1594'; end

if ~exist('nh','var'), nh=21; end
if ~exist('nit','var'), nit=5; end
if ~exist('Cic','var'), Cic=120000; end
if ~exist('file','var'), file='RNAPREV_AUTO.mat'; end
if ~exist('gravarExcel','var'), gravarExcel=1; end
if ~exist('arquivoCSV','var'), arquivoCSV='resultados_modelos.csv'; end

DADOS=[];
DADOS(:,1:input)=xlsread(EXCEL, PLAN, faixaEntrada);
DADOS(:,input+1)=xlsread(EXCEL, PLAN, faixaSaida);

f=0.05;
Prc=0.001;
Mom=0;

X(:,1)=xlsread(EXCEL,PLAN,SERIE);

if ~exist('rot_id','var'), rot_id='sem_rotacao'; end
if ~exist('evt_teste','var'), evt_teste=[]; end
if ~exist('evt_valida','var'), evt_valida=[]; end
if ~exist('tipo','var'), tipo='alt'; end
if ~exist('modelo_nome','var'), modelo_nome=file; end

% Rotacao por EVENTO. Na planilha padrao, SERIE fica na coluna B
% e EVENTO fica na coluna A, com as mesmas linhas.
if ~isempty(evt_teste) || ~isempty(evt_valida)
    EVTCOL = strrep(SERIE, 'B', 'A');
    X_evt = xlsread(EXCEL, PLAN, EVTCOL);
    for ii = 1:size(X_evt,1)
        ev = X_evt(ii);
        if ismember(ev, evt_teste)
            X(ii,1) = 3;
        elseif ismember(ev, evt_valida)
            X(ii,1) = 2;
        else
            X(ii,1) = 1;
        end
    end
    clear EVTCOL X_evt ii ev
end

treina=[]; valida=[]; verifica=[];

for i=1:size(X,1)
    if X(i)==1
        treina=[treina; DADOS(i,:)];
    elseif X(i)==2
        valida=[valida; DADOS(i,:)];
    else
        verifica=[verifica; DADOS(i,:)];
    end
end

disp('Carregamento de dados concluida!')

unisig=inline('1./(1+exp(-n))');
dunisig=inline('max(a.*(1-a),0.01)');
limsup=inline('max(v,[],2)+(max(v,[],2)-min(v,[],2)).*f','v','f');
liminf=inline('min(v,[],2)-(max(v,[],2)-min(v,[],2)).*f','v','f');
esclin=inline('(v-b*u)./(a*u)','v','a','b','u');
reclin=inline('(a*u).*s+b*u','s','a','b','u');

Pt=treina(:,1:input)'; Tt=treina(:,input+1:end)';
Ptv=valida(:,1:input)'; Ttv=valida(:,input+1:end)';
Pv=verifica(:,1:input)'; Tv=verifica(:,input+1:end)';
Ptot=DADOS(:,1:input)'; Ttot=DADOS(:,input+1:end)';

EVmin=1000000000000000;

As=unisig;
Ds=dunisig;
Ah=unisig;
Dh=dunisig;

Ut=ones(1,size(Pt,2));
Utv=ones(1,size(Ptv,2));
Uv=ones(1,size(Pv,2));
Utot=ones(1,size(Ptot,2));

disp('Realizando o escalonamento dos dados...')

ae=std(Pt,[],2);
be=mean(Pt,2);

ls=limsup(Tt,f);
li=liminf(Tt,f);
au=ls-li;
bu=li;

pt=esclin(Pt,ae,be,Ut);
ptv=esclin(Ptv,ae,be,Utv);
pv=esclin(Pv,ae,be,Uv);
ptot=esclin(Ptot,ae,be,Utot);

tt=esclin(Tt,au,bu,Ut);
ttv=esclin(Ttv,au,bu,Utv);
tv=esclin(Tv,au,bu,Uv);
ttot=esclin(Ttot,au,bu,Utot);

disp('Iniciando o treinamento da rede neural artificial...')

for i=1:nit
    [wh,bh,ws,bs,J,EQ,EV,TX,DE] = Retroprvcfn2(pt,tt,ptv,ttv,Ah,Dh,As,Ds,nh,Cic,Prc,Mom);

    if EV(:,end)<EVmin
        EVmin=EV(:,end);
        save(file,'wh','bh','ws','bs','J','EQ','EV','TX','DE','ae','be','au','bu')
    end

    format bank
    disp([num2str(i/nit*100),'% CONCLUIDO'])
end

disp('Rede neural artificial treinada!')
disp('Calculando metricas de desempenho da RNA para simulacao...')

load(file)

ATUAL_TOT=DADOS(:,1)';
ATUAL_VER=verifica(:,1)';
ATUAL_VAL=valida(:,1)';

Tctot1=reclin(As(ws*Ah(wh*ptot+bh*Utot)+bs*Utot),au,bu,Utot)+ATUAL_TOT;
Tc1=reclin(As(ws*Ah(wh*pv+bh*Uv)+bs*Uv),au,bu,Uv)+ATUAL_VER;
Tcval1=reclin(As(ws*Ah(wh*ptv+bh*Utv)+bs*Utv),au,bu,Utv)+ATUAL_VAL;

Tv1=Tv+ATUAL_VER;
Ttv1=Ttv+ATUAL_VAL;

eabs=abs(Tv1-Tc1);
emed_abs=mean(eabs);

p=[50 80 90 95 99 100];
g=prctile(eabs,p);

e2=(Tv1-Tc1).^2;
e2val=(Ttv1-Tcval1).^2;

NASH=1-sum(sum(e2))/sum(sum((Tv1-mean(mean(Tv1))).^2));
NASH_VAL=1-sum(sum(e2val))/sum(sum((Ttv1-mean(mean(Ttv1))).^2));

MPERS=verifica(:,1)';
PERS=1-sum(sum(e2))/sum(sum((Tv1-MPERS).^2));

CORRELACAO=corrcoef(Tc1,Tv1);
ERRO_RELATIVO=mean(mean(eabs./Tv1));
emed_abs_mean=emed_abs/mean(mean(Tv1));
e95=g(1,4);

format short

RESULTS=[NASH;PERS;CORRELACAO(1,2);ERRO_RELATIVO;emed_abs_mean;e95;NASH_VAL;J];

save(file)

disp('Coeficiente de Nash Sutcliffe teste = ')
disp(num2str(NASH))
disp('Coeficiente de Nash Sutcliffe validacao = ')
disp(num2str(NASH_VAL))
disp('Coeficiente de Persistencia = ')
disp(num2str(PERS))
disp('Coeficiente de Correlacao = ')
disp(num2str(CORRELACAO(1,2)))
disp('Erro Absoluto Medio = ')
disp(num2str(emed_abs))
disp('Erro Percentual = ')
disp(num2str(ERRO_RELATIVO))
disp('Erro 95% = ')
disp(num2str(e95))
disp('J = ')
disp(num2str(J))

fid=fopen(arquivoCSV,'a');

if ftell(fid)==0
    fprintf(fid,'tipo;rot_id;evt_teste;evt_valida;modelo;PLAN;input;faixaEntrada;faixaSaida;CEL;SERIE;nh;nit;Cic;J;NASH_VAL;NASH_TESTE;PERS;CORRELACAO;ERRO_RELATIVO;ERRO_ABS_MEDIO;E95;arquivo_mat\n');
end

fprintf(fid,'%s;%s;%s;%s;%s;%s;%d;%s;%s;%s;%s;%d;%d;%d;%d;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%s\n', ...
    tipo,rot_id,num2str(evt_teste),num2str(evt_valida),modelo_nome,PLAN,input,faixaEntrada,faixaSaida,CEL,SERIE,nh,nit,Cic,J,NASH_VAL,NASH,PERS,CORRELACAO(1,2),ERRO_RELATIVO,emed_abs,e95,file);

fclose(fid);

rnaout=Tctot1';

if gravarExcel==1
    disp('Tentando salvar no Excel oficial...')
    [status,msg] = xlswrite(EXCEL,rnaout,PLAN,CEL);

    if status == 1
        disp('Excel oficial salvo com sucesso!')
    else
        disp('Falha ao salvar no Excel oficial:')
        disp(msg.message)
    end
else
    disp('gravarExcel=0: Excel oficial nao foi salvo nesta rodada.')
end

toc