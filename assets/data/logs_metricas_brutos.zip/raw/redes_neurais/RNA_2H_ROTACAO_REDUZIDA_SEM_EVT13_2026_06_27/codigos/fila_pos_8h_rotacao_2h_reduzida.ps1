$ErrorActionPreference = "Continue"

$MatlabPidAnterior = 30156
$MatlabExe = "C:\Program Files\MATLAB\R2014a\bin\win64\MATLAB.exe"
$PythonExe = "C:\Users\Usuario\AppData\Local\Python\pythoncore-3.14-64\python.exe"
$RunMat = "D:\PREVINE\redes_neurais\RNA_2H_ROTACAO_REDUZIDA_SEM_EVT13_2026_06_27\codigos\run_all_rotacao_2h_reduzida.m"
$Exporter = "D:\PREVINE\redes_neurais\RNA_2H_ROTACAO_REDUZIDA_SEM_EVT13_2026_06_27\codigos\exportar_auditaveis_rotacao_2h.py"
$LogDir = "D:\PREVINE\redes_neurais\RNA_2H_ROTACAO_REDUZIDA_SEM_EVT13_2026_06_27\logs"
$Log = Join-Path $LogDir "fila_pos_8h_rotacao_2h_reduzida.log"

New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

function Write-QueueLog {
    param([string]$Message)
    $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -LiteralPath $Log -Value "$stamp $Message"
}

Write-QueueLog "Fila criada. Aguardando MATLAB PID $MatlabPidAnterior finalizar antes de iniciar rotacao 2h reduzida."

while (Get-Process -Id $MatlabPidAnterior -ErrorAction SilentlyContinue) {
    Start-Sleep -Seconds 60
}

Write-QueueLog "MATLAB anterior finalizou. Iniciando exportador auditavel em modo watch."

Start-Process `
    -FilePath $PythonExe `
    -ArgumentList @($Exporter, "--watch", "--interval", "60") `
    -WindowStyle Hidden `
    -RedirectStandardOutput (Join-Path $LogDir "exportador_rotacao_2h.out.log") `
    -RedirectStandardError (Join-Path $LogDir "exportador_rotacao_2h.err.log")

Write-QueueLog "Iniciando MATLAB da rotacao 2h reduzida."

$RunArg = "run('$($RunMat.Replace('\','/'))'); exit"
$proc = Start-Process `
    -FilePath $MatlabExe `
    -ArgumentList @("-nosplash", "-nodesktop", "-r", $RunArg) `
    -WindowStyle Hidden `
    -PassThru

Write-QueueLog "MATLAB rotacao 2h iniciado com PID $($proc.Id)."
$proc.WaitForExit()
Write-QueueLog "MATLAB rotacao 2h finalizou com ExitCode $($proc.ExitCode). Rodando exportacao final."

& $PythonExe $Exporter | Out-File -FilePath (Join-Path $LogDir "exportador_rotacao_2h_final.out.log") -Encoding utf8

Write-QueueLog "Fila finalizada."
