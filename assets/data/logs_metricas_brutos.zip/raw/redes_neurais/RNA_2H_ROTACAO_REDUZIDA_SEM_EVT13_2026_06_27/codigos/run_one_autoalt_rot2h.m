function run_one_autoalt_rot2h(EXCEL, PLAN, input, faixaEntrada, faixaSaida, CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV, rot_id, evt_teste, evt_valida, tipo, modelo_nome)
modelo_autoalt_rot2h;
end
