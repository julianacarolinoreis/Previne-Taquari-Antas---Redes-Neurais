@echo off
REM =====================================================================
REM  RETOMA o treinamento 12H ALT/CONV a partir do item 14/32.
REM  Gerado pelo agente de continuidade em 2026-07-02.
REM
REM  MOTIVO: o run original (run_all_12h_alt_conv.m) iniciou o item
REM  14/32 (14_12h_alt_12H_ALT_C0921) as 01:52:39 (hora local) e nao
REM  produziu nenhum resultado ou log novo ate as 08:07 do dia seguinte
REM  (~6h paradas, muito acima dos ~35 min tipicos por modelo). Os
REM  itens 1-13 ja foram concluidos e estao preservados nos arquivos
REM  resultados_modelo_12h_alt_conv.csv e status_modelo_12h_alt_conv.csv
REM  - este script NAO apaga esses resultados, apenas continua do 14.
REM
REM  ATENCAO ANTES DE RODAR:
REM  1) Confirme no Gerenciador de Tarefas que NAO ha nenhum processo
REM     MATLAB.exe relacionado a pasta RNA_12H_ALT_CONV_MONTAGEM_REGRAS
REM     ainda em execucao (pode estar apenas lento, nao travado).
REM     Se houver, NAO rode este .bat - aguarde ou encerre-o primeiro.
REM  2) Este .bat foi preparado mas NAO foi executado automaticamente
REM     pelo agente porque a sessao agendada nao tem permissao para
REM     controlar o computador (isso exige aprovacao interativa sua).
REM =====================================================================

start "" /B "C:\Users\Usuario\AppData\Local\Python\pythoncore-3.14-64\python.exe" "D:\PREVINE\redes_neurais\RNA_12H_ALT_CONV_MONTAGEM_REGRAS_2026_07_01\codigos\exportar_auditaveis_12h_alt_conv.py" --watch --interval 60

"C:\Program Files\MATLAB\R2014a\bin\win64\MATLAB.exe" -nosplash -nodesktop -r "run('D:/PREVINE/redes_neurais/RNA_12H_ALT_CONV_MONTAGEM_REGRAS_2026_07_01/codigos/run_all_12h_alt_conv_RETOMAR_ITEM14.m'); exit"
