function run_one_auto(EXCEL, PLAN, input, faixaEntrada, faixaSaida, CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV)
modelo_auto;
end
