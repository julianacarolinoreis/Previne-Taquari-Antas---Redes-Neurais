@echo off
C:\Users\Usuario\AppData\Local\Python\bin\python.exe D:\PREVINE\redes_neurais\fila_rotacao_eventos.py
