clear; clc;
codeDir = 'D:/PREVINE/redes_neurais/RNA_8H_CONV_ROTACAO_CORRIGIDA_2026_06_30/codigos';
addpath(codeDir);
resultCsv = 'D:/PREVINE/redes_neurais/RNA_8H_CONV_ROTACAO_CORRIGIDA_2026_06_30/resultados_rotacao_8h_conv_corrigida.csv';
statusCsv = 'D:/PREVINE/redes_neurais/RNA_8H_CONV_ROTACAO_CORRIGIDA_2026_06_30/status/status_rotacao_8h_conv_corrigida.csv';
logFile = 'D:/PREVINE/redes_neurais/RNA_8H_CONV_ROTACAO_CORRIGIDA_2026_06_30/logs/run_resume_rotacao_8h_conv_filtrada.log';
if ~exist(statusCsv,'file')
    fid=fopen(statusCsv,'w'); fprintf(fid,'rot_id;ordem;tipo;planilha;evt_teste;evt_valida;status;inicio;fim;mensagem\n'); fclose(fid);
end
diary(logFile);
disp('Retomada filtrada 8h CONV: removidas validacoes com eventos 7/12/14');
disp(['Pendentes filtrados: ', num2str(3)]);
plans = repmat(struct('orig_order',0,'rot_id','','name','','excel','','input',0,'nh',0,'faixaEntrada','','faixaSaida','','SERIE','','CEL','','mat','','evt_teste','','evt_valida',''), 1, 3);
plans(1).orig_order = 52;
plans(1).rot_id = 'conv8hR_009';
plans(1).name = 'conv8hR_009_24_8h_conv_8H_CONV_C0289';
plans(1).excel = 'D:/PREVINE/redes_neurais/RNA_8H_CONV_ROTACAO_CORRIGIDA_2026_06_30/planilhas/conv8hR_009_24_8h_conv_8H_CONV_C0289.xlsx';
plans(1).input = 10;
plans(1).nh = 20;
plans(1).faixaEntrada = 'K2:T2882';
plans(1).faixaSaida = 'U2:U2882';
plans(1).SERIE = 'B2:B2882';
plans(1).CEL = 'W2:W2882';
plans(1).mat = 'D:/PREVINE/redes_neurais/RNA_8H_CONV_ROTACAO_CORRIGIDA_2026_06_30/mat/conv8hR_009_24_8h_conv_8H_CONV_C0289.mat';
plans(1).evt_teste = '14';
plans(1).evt_valida = '1 2';
plans(2).orig_order = 53;
plans(2).rot_id = 'conv8hR_009';
plans(2).name = 'conv8hR_009_31_8h_conv_8H_CONV_C0268';
plans(2).excel = 'D:/PREVINE/redes_neurais/RNA_8H_CONV_ROTACAO_CORRIGIDA_2026_06_30/planilhas/conv8hR_009_31_8h_conv_8H_CONV_C0268.xlsx';
plans(2).input = 11;
plans(2).nh = 22;
plans(2).faixaEntrada = 'K2:U2888';
plans(2).faixaSaida = 'V2:V2888';
plans(2).SERIE = 'B2:B2888';
plans(2).CEL = 'X2:X2888';
plans(2).mat = 'D:/PREVINE/redes_neurais/RNA_8H_CONV_ROTACAO_CORRIGIDA_2026_06_30/mat/conv8hR_009_31_8h_conv_8H_CONV_C0268.mat';
plans(2).evt_teste = '14';
plans(2).evt_valida = '1 2';
plans(3).orig_order = 54;
plans(3).rot_id = 'conv8hR_009';
plans(3).name = 'conv8hR_009_19_8h_conv_8H_CONV_C0265';
plans(3).excel = 'D:/PREVINE/redes_neurais/RNA_8H_CONV_ROTACAO_CORRIGIDA_2026_06_30/planilhas/conv8hR_009_19_8h_conv_8H_CONV_C0265.xlsx';
plans(3).input = 8;
plans(3).nh = 16;
plans(3).faixaEntrada = 'K2:R2917';
plans(3).faixaSaida = 'S2:S2917';
plans(3).SERIE = 'B2:B2917';
plans(3).CEL = 'U2:U2917';
plans(3).mat = 'D:/PREVINE/redes_neurais/RNA_8H_CONV_ROTACAO_CORRIGIDA_2026_06_30/mat/conv8hR_009_19_8h_conv_8H_CONV_C0265.mat';
plans(3).evt_teste = '14';
plans(3).evt_valida = '1 2';
for k=1:length(plans)
    inicio = datestr(now, 'yyyy-mm-dd HH:MM:SS');
    fprintf('\n==== FILTRADO %d/%d ordem %d %s %s ====\n', k, length(plans), plans(k).orig_order, plans(k).rot_id, plans(k).name);
    fid=fopen(statusCsv,'a'); fprintf(fid,'%s;%d;%s;%s;%s;%s;%s;%s;%s;%s\n', plans(k).rot_id, plans(k).orig_order, 'conv', plans(k).name, plans(k).evt_teste, plans(k).evt_valida, 'INICIADO', inicio, '', ''); fclose(fid);
    try
        EXCEL = plans(k).excel; PLAN = 'DADOS'; input = plans(k).input;
        faixaEntrada = plans(k).faixaEntrada; faixaSaida = plans(k).faixaSaida;
        CEL = plans(k).CEL; SERIE = plans(k).SERIE; nh = plans(k).nh;
        nit = 10; Cic = 100000; file = plans(k).mat;
        gravarExcel = 0; arquivoCSV = resultCsv;
        run_one_auto(EXCEL, PLAN, input, faixaEntrada, faixaSaida, CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV);
        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        fid=fopen(statusCsv,'a'); fprintf(fid,'%s;%d;%s;%s;%s;%s;%s;%s;%s;%s\n', plans(k).rot_id, plans(k).orig_order, 'conv', plans(k).name, plans(k).evt_teste, plans(k).evt_valida, 'CONCLUIDO', inicio, fim, ''); fclose(fid);
    catch ME
        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        msg = strrep(ME.message, ';', ','); msg = strrep(msg, sprintf('\n'), ' ');
        fid=fopen(statusCsv,'a'); fprintf(fid,'%s;%d;%s;%s;%s;%s;%s;%s;%s;%s\n', plans(k).rot_id, plans(k).orig_order, 'conv', plans(k).name, plans(k).evt_teste, plans(k).evt_valida, 'ERRO', inicio, fim, msg); fclose(fid);
        disp(getReport(ME));
    end
end
disp('Retomada filtrada 8h CONV finalizada');
diary off;
exit;