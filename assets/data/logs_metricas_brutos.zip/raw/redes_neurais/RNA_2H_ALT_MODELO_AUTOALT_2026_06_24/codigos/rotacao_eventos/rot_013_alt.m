clear; clc;
% Rotação 013: TESTE=evt2(jun23), VALIDACAO=evt12(set24), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [2];
evt_valida = [12];
run_all_rotacao_alt('rot_013', evt_teste, evt_valida);
exit;
