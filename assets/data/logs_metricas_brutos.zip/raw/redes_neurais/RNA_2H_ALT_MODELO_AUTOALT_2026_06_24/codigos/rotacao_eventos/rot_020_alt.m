clear; clc;
% Rotação 020: TESTE=evt3(jul23), VALIDACAO=evt2(jun23), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [3];
evt_valida = [2];
run_all_rotacao_alt('rot_020', evt_teste, evt_valida);
exit;
