function run_all_rotacao_alt(rot_id, evt_teste, evt_valida)
% Roda todos os 12 modelos ALT com a rotacao de eventos especificada.
% rot_id   : string ex. 'rot_001'
% evt_teste : array de IDs de evento para TESTE    (serie=3)
% evt_valida: array de IDs de evento para VALIDACAO (serie=2)
% Fixos sempre Treino: 4 (set/23), 5 (nov/23), 7 (abr/24), 8 (abr-mai/24)

rotDir     = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/rotacao';
resultCsv  = [rotDir '/resultados/' rot_id '_alt.csv'];
statusCsv  = [rotDir '/status/'     rot_id '_alt_status.csv'];
logFile    = [rotDir '/logs/'       rot_id '_alt.log'];
matDir     = [rotDir '/mat'];

diary(logFile);
fprintf('\n====== Rotacao %s | ALT | teste=%s valida=%s ======\n', rot_id, num2str(evt_teste), num2str(evt_valida));
fid=fopen(statusCsv,'w'); fprintf(fid,'ordem;planilha;status;inicio;fim;mensagem\n'); fclose(fid);

plans = repmat(struct('name','','excel','','input',0,'nh',0,'faixaEntrada','','faixaSaida','','SERIE','','CEL',''), 1, 12);
plans(1).name = '01_2h_alt_2H_ALT_C0080';
plans(1).excel = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/planilhas/01_2h_alt_2H_ALT_C0080.xlsx';
plans(1).input = 14;
plans(1).nh = 28;
plans(1).faixaEntrada = 'K2:X2868';
plans(1).faixaSaida = 'Y2:Y2868';
plans(1).SERIE = 'B2:B2868';
plans(1).CEL = 'AA2:AA2868';
plans(2).name = '02_2h_alt_2H_ALT_C0224';
plans(2).excel = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/planilhas/02_2h_alt_2H_ALT_C0224.xlsx';
plans(2).input = 14;
plans(2).nh = 28;
plans(2).faixaEntrada = 'K2:X2859';
plans(2).faixaSaida = 'Y2:Y2859';
plans(2).SERIE = 'B2:B2859';
plans(2).CEL = 'AA2:AA2859';
plans(3).name = '03_2h_alt_2H_ALT_C0079';
plans(3).excel = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/planilhas/03_2h_alt_2H_ALT_C0079.xlsx';
plans(3).input = 12;
plans(3).nh = 24;
plans(3).faixaEntrada = 'K2:V2897';
plans(3).faixaSaida = 'W2:W2897';
plans(3).SERIE = 'B2:B2897';
plans(3).CEL = 'Y2:Y2897';
plans(4).name = '04_2h_alt_2H_ALT_C0223';
plans(4).excel = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/planilhas/04_2h_alt_2H_ALT_C0223.xlsx';
plans(4).input = 12;
plans(4).nh = 24;
plans(4).faixaEntrada = 'K2:V2888';
plans(4).faixaSaida = 'W2:W2888';
plans(4).SERIE = 'B2:B2888';
plans(4).CEL = 'Y2:Y2888';
plans(5).name = '05_2h_alt_2H_ALT_C0088';
plans(5).excel = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/planilhas/05_2h_alt_2H_ALT_C0088.xlsx';
plans(5).input = 14;
plans(5).nh = 28;
plans(5).faixaEntrada = 'K2:X2850';
plans(5).faixaSaida = 'Y2:Y2850';
plans(5).SERIE = 'B2:B2850';
plans(5).CEL = 'AA2:AA2850';
plans(6).name = '06_2h_alt_2H_ALT_C0472';
plans(6).excel = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/planilhas/06_2h_alt_2H_ALT_C0472.xlsx';
plans(6).input = 15;
plans(6).nh = 30;
plans(6).faixaEntrada = 'K2:Y1817';
plans(6).faixaSaida = 'Z2:Z1817';
plans(6).SERIE = 'B2:B1817';
plans(6).CEL = 'AB2:AB1817';
plans(7).name = '07_2h_alt_2H_ALT_C0096';
plans(7).excel = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/planilhas/07_2h_alt_2H_ALT_C0096.xlsx';
plans(7).input = 14;
plans(7).nh = 28;
plans(7).faixaEntrada = 'K2:X2837';
plans(7).faixaSaida = 'Y2:Y2837';
plans(7).SERIE = 'B2:B2837';
plans(7).CEL = 'AA2:AA2837';
plans(8).name = '08_2h_alt_2H_ALT_C0616';
plans(8).excel = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/planilhas/08_2h_alt_2H_ALT_C0616.xlsx';
plans(8).input = 15;
plans(8).nh = 30;
plans(8).faixaEntrada = 'K2:Y1811';
plans(8).faixaSaida = 'Z2:Z1811';
plans(8).SERIE = 'B2:B1811';
plans(8).CEL = 'AB2:AB1811';
plans(9).name = '09_2h_alt_2H_ALT_C0471';
plans(9).excel = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/planilhas/09_2h_alt_2H_ALT_C0471.xlsx';
plans(9).input = 13;
plans(9).nh = 26;
plans(9).faixaEntrada = 'K2:W1845';
plans(9).faixaSaida = 'X2:X1845';
plans(9).SERIE = 'B2:B1845';
plans(9).CEL = 'Z2:Z1845';
plans(10).name = '10_2h_alt_2H_ALT_C0087';
plans(10).excel = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/planilhas/10_2h_alt_2H_ALT_C0087.xlsx';
plans(10).input = 12;
plans(10).nh = 24;
plans(10).faixaEntrada = 'K2:V2879';
plans(10).faixaSaida = 'W2:W2879';
plans(10).SERIE = 'B2:B2879';
plans(10).CEL = 'Y2:Y2879';
plans(11).name = '11_2h_alt_2H_ALT_C0615';
plans(11).excel = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/planilhas/11_2h_alt_2H_ALT_C0615.xlsx';
plans(11).input = 13;
plans(11).nh = 26;
plans(11).faixaEntrada = 'K2:W1839';
plans(11).faixaSaida = 'X2:X1839';
plans(11).SERIE = 'B2:B1839';
plans(11).CEL = 'Z2:Z1839';
plans(12).name = '12_2h_alt_2H_ALT_C0095';
plans(12).excel = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/planilhas/12_2h_alt_2H_ALT_C0095.xlsx';
plans(12).input = 12;
plans(12).nh = 24;
plans(12).faixaEntrada = 'K2:V2865';
plans(12).faixaSaida = 'W2:W2865';
plans(12).SERIE = 'B2:B2865';
plans(12).CEL = 'Y2:Y2865';

for k=1:length(plans)
    inicio = datestr(now, 'yyyy-mm-dd HH:MM:SS');
    fprintf('\n-- %d/12 %s --\n', k, plans(k).name);
    fid=fopen(statusCsv,'a'); fprintf(fid,'%d;%s;%s;%s;%s;%s\n', k, plans(k).name, 'INICIADO', inicio, '', ''); fclose(fid);
    try
        EXCEL = plans(k).excel;
        PLAN  = 'DADOS';
        input = plans(k).input;
        faixaEntrada = plans(k).faixaEntrada;
        faixaSaida   = plans(k).faixaSaida;
        CEL   = plans(k).CEL;
        SERIE = plans(k).SERIE;
        nh    = plans(k).nh;
        nit   = 10;
        Cic   = 100000;
        file  = [matDir '/' rot_id '_' plans(k).name '.mat'];
        gravarExcel = 0;
        arquivoCSV  = resultCsv;
        run_one_autoalt_rot(EXCEL, PLAN, input, faixaEntrada, faixaSaida, CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV, evt_teste, evt_valida);
        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        fid=fopen(statusCsv,'a'); fprintf(fid,'%d;%s;%s;%s;%s;%s\n', k, plans(k).name, 'CONCLUIDO', inicio, fim, ''); fclose(fid);
    catch ME
        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        msg = strrep(ME.message, ';', ',');
        msg = strrep(msg, sprintf('\n'), ' ');
        fid=fopen(statusCsv,'a'); fprintf(fid,'%d;%s;%s;%s;%s;%s\n', k, plans(k).name, 'ERRO', inicio, fim, msg); fclose(fid);
        disp(getReport(ME));
    end
end
fprintf('Rotacao %s ALT finalizada.\n', rot_id);
diary off;
end
