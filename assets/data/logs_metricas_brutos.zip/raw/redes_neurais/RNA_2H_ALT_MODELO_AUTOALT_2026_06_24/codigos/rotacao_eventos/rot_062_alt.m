clear; clc;
% Rotação 062: TESTE=evt14(dez24b), VALIDACAO=evt19(ago25), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [14];
evt_valida = [19];
run_all_rotacao_alt('rot_062', evt_teste, evt_valida);
exit;
