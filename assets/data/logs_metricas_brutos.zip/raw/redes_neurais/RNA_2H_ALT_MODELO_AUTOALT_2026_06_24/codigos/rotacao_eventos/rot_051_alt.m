clear; clc;
% Rotação 051: TESTE=evt13(dez24a), VALIDACAO=evt14(dez24b), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [13];
evt_valida = [14];
run_all_rotacao_alt('rot_051', evt_teste, evt_valida);
exit;
