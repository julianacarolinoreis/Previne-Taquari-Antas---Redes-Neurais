clear; clc;
% Rotação 039: TESTE=evt12(set24), VALIDACAO=evt3(jul23), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [12];
evt_valida = [3];
run_all_rotacao_alt('rot_039', evt_teste, evt_valida);
exit;
