clear; clc;
% Rotação 054: TESTE=evt13(dez24a), VALIDACAO=evt20(set25), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [13];
evt_valida = [20];
run_all_rotacao_alt('rot_054', evt_teste, evt_valida);
exit;
