clear; clc;
% Rotação 058: TESTE=evt14(dez24b), VALIDACAO=evt7(abr24a), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [14];
evt_valida = [7];
run_all_rotacao_alt('rot_058', evt_teste, evt_valida);
exit;
