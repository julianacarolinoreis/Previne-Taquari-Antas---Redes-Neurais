clear; clc;
% Rotação 076: TESTE=evt19(ago25), VALIDACAO=evt7(abr24a), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [19];
evt_valida = [7];
run_all_rotacao_alt('rot_076', evt_teste, evt_valida);
exit;
