clear; clc;
% Rotação 075: TESTE=evt19(ago25), VALIDACAO=evt3(jul23), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [19];
evt_valida = [3];
run_all_rotacao_alt('rot_075', evt_teste, evt_valida);
exit;
