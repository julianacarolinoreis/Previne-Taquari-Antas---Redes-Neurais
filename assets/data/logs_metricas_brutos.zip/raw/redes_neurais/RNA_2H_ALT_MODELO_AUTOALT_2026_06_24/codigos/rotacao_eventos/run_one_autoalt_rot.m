function run_one_autoalt_rot(EXCEL, PLAN, input, faixaEntrada, faixaSaida, CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV, evt_teste, evt_valida)
% Wrapper para rotacao de eventos - preserva loop externo durante clearvars.
modelo_autoalt_rot;
end
