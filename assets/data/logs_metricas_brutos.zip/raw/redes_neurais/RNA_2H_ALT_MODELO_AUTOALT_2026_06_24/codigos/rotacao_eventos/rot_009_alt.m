clear; clc;
% Rotação 009: TESTE=evt1(mai23), VALIDACAO=evt20(set25), FIXOS_TREINO=[4,5,8]
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos');
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_2026_06_24/codigos/rotacao_eventos');
evt_teste  = [1];
evt_valida = [20];
run_all_rotacao_alt('rot_009', evt_teste, evt_valida);
exit;
