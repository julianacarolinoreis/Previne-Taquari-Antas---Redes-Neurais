@echo off
echo Deletando 26 arquivos de modelos com PERS_GERAL negativo...
echo.

REM === 2H CONV (6 modelos negativos) ===
set BASE2H=D:\PREVINE\redes_neurais\RNA_2H_CONV_MODELO_AUTO_2026_06_24

del /f "%BASE2H%\mat\13_2h_conv_2H_CONV_C0001.mat"
del /f "%BASE2H%\mat\16_2h_conv_2H_CONV_C0785.mat"
del /f "%BASE2H%\mat\17_2h_conv_2H_CONV_C0793.mat"
del /f "%BASE2H%\mat\18_2h_conv_2H_CONV_C0393.mat"
del /f "%BASE2H%\mat\19_2h_conv_2H_CONV_C0897.mat"
del /f "%BASE2H%\mat\20_2h_conv_2H_CONV_C0497.mat"

del /f "%BASE2H%\resultados_excel_auditaveis\13_2h_conv_2H_CONV_C0001_RESULTADO_AUDITAVEL.xlsx"
del /f "%BASE2H%\resultados_excel_auditaveis\16_2h_conv_2H_CONV_C0785_RESULTADO_AUDITAVEL.xlsx"
del /f "%BASE2H%\resultados_excel_auditaveis\17_2h_conv_2H_CONV_C0793_RESULTADO_AUDITAVEL.xlsx"
del /f "%BASE2H%\resultados_excel_auditaveis\18_2h_conv_2H_CONV_C0393_RESULTADO_AUDITAVEL.xlsx"
del /f "%BASE2H%\resultados_excel_auditaveis\19_2h_conv_2H_CONV_C0897_RESULTADO_AUDITAVEL.xlsx"
del /f "%BASE2H%\resultados_excel_auditaveis\20_2h_conv_2H_CONV_C0497_RESULTADO_AUDITAVEL.xlsx"

REM === 8H ALT (4 modelos negativos) ===
set BASE8H=D:\PREVINE\redes_neurais\RNA_8H_ALT_CONV_MODELO_AUTO_2026_06_27

del /f "%BASE8H%\mat\02_8h_alt_8H_ALT_C0073.mat"
del /f "%BASE8H%\mat\05_8h_alt_8H_ALT_C0193.mat"
del /f "%BASE8H%\mat\06_8h_alt_8H_ALT_C0217.mat"
del /f "%BASE8H%\mat\12_8h_alt_8H_ALT_C0078.mat"

del /f "%BASE8H%\resultados_excel_auditaveis\02_8h_alt_8H_ALT_C0073_AUDITAVEL_INPUTS_RNA.xlsx"
del /f "%BASE8H%\resultados_excel_auditaveis\05_8h_alt_8H_ALT_C0193_AUDITAVEL_INPUTS_RNA.xlsx"
del /f "%BASE8H%\resultados_excel_auditaveis\06_8h_alt_8H_ALT_C0217_AUDITAVEL_INPUTS_RNA.xlsx"
del /f "%BASE8H%\resultados_excel_auditaveis\12_8h_alt_8H_ALT_C0078_AUDITAVEL_INPUTS_RNA.xlsx"

REM === 8H CONV (3 modelos negativos) ===
del /f "%BASE8H%\mat\25_8h_conv_8H_CONV_C0657.mat"
del /f "%BASE8H%\mat\26_8h_conv_8H_CONV_C0569.mat"
del /f "%BASE8H%\mat\32_8h_conv_8H_CONV_C0659.mat"

del /f "%BASE8H%\resultados_excel_auditaveis\25_8h_conv_8H_CONV_C0657_AUDITAVEL_INPUTS_RNA.xlsx"
del /f "%BASE8H%\resultados_excel_auditaveis\26_8h_conv_8H_CONV_C0569_AUDITAVEL_INPUTS_RNA.xlsx"
del /f "%BASE8H%\resultados_excel_auditaveis\32_8h_conv_8H_CONV_C0659_AUDITAVEL_INPUTS_RNA.xlsx"

echo.
echo Concluido. Verifique as mensagens acima.
pause
