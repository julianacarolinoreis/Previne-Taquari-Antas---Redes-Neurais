@echo off
"C:\Users\Usuario\AppData\Local\Python\pythoncore-3.14-64\python.exe" "D:\PREVINE\redes_neurais\RNA_MELHORIAS_DIRIGIDAS_SEM4H_2026_07_02\00_SUPERVISOR\supervisor_pos_12h_melhorias_sem4h.py"
