% Aguarda a fila extras_completa terminar e entao inicia treinamento recorte
% Gate: mat do plano 12 da fila extras_completa
gateMat = 'D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_EXTRAS_SEM_12_17_2026_06_24/mat/12_2h_alt_2H_ALT_C0095.mat';

fprintf('Aguardando fila extras_completa terminar...\n');
fprintf('Gate: %s\n', gateMat);

while ~exist(gateMat, 'file')
    fprintf('[%s] Aguardando...\n', datestr(now, 'HH:MM:SS'));
    pause(120);  % checa a cada 2 minutos
end

fprintf('[%s] Gate encontrado! Iniciando recorte...\n', datestr(now, 'HH:MM:SS'));
pause(30);  % pequena pausa para garantir que o MATLAB anterior fechou

cd('D:/PREVINE/redes_neurais/00_PLANILHAS2altrecorte');
run('run_all_2h_alt_recorte.m');
