% Treinamento 2h_alt — tabelas com recorte de linhas
% Mesmas configuracoes: nit=10, Cic=100000, nh=2x inputs
clear; clc;

recorteDir = 'D:/PREVINE/redes_neurais/00_PLANILHAS2altrecorte';
completaDir = [recorteDir '/00_PLANILHAS_COMPLETAS_COM_INPUTS_E_RNA'];

resultCsv = [recorteDir '/resultados_2h_alt_recorte.csv'];
statusCsv = [recorteDir '/status/status_2h_alt_recorte.csv'];
logFile   = [recorteDir '/logs/run_all_2h_alt_recorte.log'];

% Adicionar codigos do modelo principal ao path (onde fica run_one_autoalt)
addpath('D:/PREVINE/redes_neurais/RNA_2H_ALT_MODELO_AUTOALT_EXTRAS_SEM_12_17_2026_06_24/codigos');

diary(logFile);
disp('=== Treinamento 2h_alt RECORTE ===');
disp(datestr(now, 'yyyy-mm-dd HH:MM:SS'));

plans = repmat(struct('name','','excel','','input',0,'nh',0, ...
    'faixaEntrada','','faixaSaida','','SERIE','','CEL','','mat',''), 1, 12);

% --- Plan 1: C0080 — 14 inputs, 1920 linhas ---
plans(1).name = '01_2h_alt_2H_ALT_C0080';
plans(1).excel = [completaDir '/01_2h_alt_2H_ALT_C0080_COMPLETA_INPUTS_RNA.xlsx'];
plans(1).input = 14; plans(1).nh = 28;
plans(1).faixaEntrada = 'K2:X1920'; plans(1).faixaSaida = 'Y2:Y1920';
plans(1).SERIE = 'B2:B1920'; plans(1).CEL = 'AB2:AB1920';
plans(1).mat = [recorteDir '/mat/01_2h_alt_2H_ALT_C0080.mat'];

% --- Plan 2: C0224 — 14 inputs, 1657 linhas ---
plans(2).name = '02_2h_alt_2H_ALT_C0224';
plans(2).excel = [completaDir '/02_2h_alt_2H_ALT_C0224_COMPLETA_INPUTS_RNA.xlsx'];
plans(2).input = 14; plans(2).nh = 28;
plans(2).faixaEntrada = 'K2:X1657'; plans(2).faixaSaida = 'Y2:Y1657';
plans(2).SERIE = 'B2:B1657'; plans(2).CEL = 'AB2:AB1657';
plans(2).mat = [recorteDir '/mat/02_2h_alt_2H_ALT_C0224.mat'];

% --- Plan 3: C0079 — 12 inputs, 1860 linhas ---
plans(3).name = '03_2h_alt_2H_ALT_C0079';
plans(3).excel = [completaDir '/03_2h_alt_2H_ALT_C0079_COMPLETA_INPUTS_RNA.xlsx'];
plans(3).input = 12; plans(3).nh = 24;
plans(3).faixaEntrada = 'K2:V1860'; plans(3).faixaSaida = 'W2:W1860';
plans(3).SERIE = 'B2:B1860'; plans(3).CEL = 'Z2:Z1860';
plans(3).mat = [recorteDir '/mat/03_2h_alt_2H_ALT_C0079.mat'];

% --- Plan 4: C0223 — 12 inputs, 1794 linhas ---
plans(4).name = '04_2h_alt_2H_ALT_C0223';
plans(4).excel = [completaDir '/04_2h_alt_2H_ALT_C0223_COMPLETA_INPUTS_RNA.xlsx'];
plans(4).input = 12; plans(4).nh = 24;
plans(4).faixaEntrada = 'K2:V1794'; plans(4).faixaSaida = 'W2:W1794';
plans(4).SERIE = 'B2:B1794'; plans(4).CEL = 'Z2:Z1794';
plans(4).mat = [recorteDir '/mat/04_2h_alt_2H_ALT_C0223.mat'];

% --- Plan 5: C0088 — 14 inputs, 1945 linhas ---
plans(5).name = '05_2h_alt_2H_ALT_C0088';
plans(5).excel = [completaDir '/05_2h_alt_2H_ALT_C0088_COMPLETA_INPUTS_RNA.xlsx'];
plans(5).input = 14; plans(5).nh = 28;
plans(5).faixaEntrada = 'K2:X1945'; plans(5).faixaSaida = 'Y2:Y1945';
plans(5).SERIE = 'B2:B1945'; plans(5).CEL = 'AB2:AB1945';
plans(5).mat = [recorteDir '/mat/05_2h_alt_2H_ALT_C0088.mat'];

% --- Plan 6: C0472 — 15 inputs, 1160 linhas ---
plans(6).name = '06_2h_alt_2H_ALT_C0472';
plans(6).excel = [completaDir '/06_2h_alt_2H_ALT_C0472_COMPLETA_INPUTS_RNA.xlsx'];
plans(6).input = 15; plans(6).nh = 30;
plans(6).faixaEntrada = 'K2:Y1160'; plans(6).faixaSaida = 'Z2:Z1160';
plans(6).SERIE = 'B2:B1160'; plans(6).CEL = 'AC2:AC1160';
plans(6).mat = [recorteDir '/mat/06_2h_alt_2H_ALT_C0472.mat'];

% --- Plan 7: C0096 — 14 inputs, 1863 linhas ---
plans(7).name = '07_2h_alt_2H_ALT_C0096';
plans(7).excel = [completaDir '/07_2h_alt_2H_ALT_C0096_COMPLETA_INPUTS_RNA.xlsx'];
plans(7).input = 14; plans(7).nh = 28;
plans(7).faixaEntrada = 'K2:X1863'; plans(7).faixaSaida = 'Y2:Y1863';
plans(7).SERIE = 'B2:B1863'; plans(7).CEL = 'AB2:AB1863';
plans(7).mat = [recorteDir '/mat/07_2h_alt_2H_ALT_C0096.mat'];

% --- Plan 8: C0616 — 15 inputs, 1073 linhas ---
plans(8).name = '08_2h_alt_2H_ALT_C0616';
plans(8).excel = [completaDir '/08_2h_alt_2H_ALT_C0616_COMPLETA_INPUTS_RNA.xlsx'];
plans(8).input = 15; plans(8).nh = 30;
plans(8).faixaEntrada = 'K2:Y1073'; plans(8).faixaSaida = 'Z2:Z1073';
plans(8).SERIE = 'B2:B1073'; plans(8).CEL = 'AC2:AC1073';
plans(8).mat = [recorteDir '/mat/08_2h_alt_2H_ALT_C0616.mat'];

% --- Plan 9: C0471 — 13 inputs, 1120 linhas ---
plans(9).name = '09_2h_alt_2H_ALT_C0471';
plans(9).excel = [completaDir '/09_2h_alt_2H_ALT_C0471_COMPLETA_INPUTS_RNA.xlsx'];
plans(9).input = 13; plans(9).nh = 26;
plans(9).faixaEntrada = 'K2:W1120'; plans(9).faixaSaida = 'X2:X1120';
plans(9).SERIE = 'B2:B1120'; plans(9).CEL = 'AA2:AA1120';
plans(9).mat = [recorteDir '/mat/09_2h_alt_2H_ALT_C0471.mat'];

% --- Plan 10: C0087 — 12 inputs, 1960 linhas ---
plans(10).name = '10_2h_alt_2H_ALT_C0087';
plans(10).excel = [completaDir '/10_2h_alt_2H_ALT_C0087_COMPLETA_INPUTS_RNA.xlsx'];
plans(10).input = 12; plans(10).nh = 24;
plans(10).faixaEntrada = 'K2:V1960'; plans(10).faixaSaida = 'W2:W1960';
plans(10).SERIE = 'B2:B1960'; plans(10).CEL = 'Z2:Z1960';
plans(10).mat = [recorteDir '/mat/10_2h_alt_2H_ALT_C0087.mat'];

% --- Plan 11: C0615 — 13 inputs, 933 linhas ---
plans(11).name = '11_2h_alt_2H_ALT_C0615';
plans(11).excel = [completaDir '/11_2h_alt_2H_ALT_C0615_COMPLETA_INPUTS_RNA.xlsx'];
plans(11).input = 13; plans(11).nh = 26;
plans(11).faixaEntrada = 'K2:W933'; plans(11).faixaSaida = 'X2:X933';
plans(11).SERIE = 'B2:B933'; plans(11).CEL = 'AA2:AA933';
plans(11).mat = [recorteDir '/mat/11_2h_alt_2H_ALT_C0615.mat'];

% --- Plan 12: C0095 — 12 inputs, 1866 linhas ---
plans(12).name = '12_2h_alt_2H_ALT_C0095';
plans(12).excel = [completaDir '/12_2h_alt_2H_ALT_C0095_COMPLETA_INPUTS_RNA.xlsx'];
plans(12).input = 12; plans(12).nh = 24;
plans(12).faixaEntrada = 'K2:V1866'; plans(12).faixaSaida = 'W2:W1866';
plans(12).SERIE = 'B2:B1866'; plans(12).CEL = 'Z2:Z1866';
plans(12).mat = [recorteDir '/mat/12_2h_alt_2H_ALT_C0095.mat'];

% --- Loop ---
for k = 1:12
    if exist(plans(k).mat, 'file')
        fprintf('\n[SKIP] %d/12 %s — mat ja existe\n', k, plans(k).name);
        continue;
    end

    inicio = datestr(now, 'yyyy-mm-dd HH:MM:SS');
    fprintf('\n==== %d/12 %s ====\n', k, plans(k).name);
    fid = fopen(statusCsv, 'a');
    fprintf(fid, '%d;%s;%s;%s;%s;%s\n', k, plans(k).name, 'INICIADO', inicio, '', '');
    fclose(fid);

    try
        EXCEL        = plans(k).excel;
        PLAN         = 'DADOS';
        input        = plans(k).input;
        faixaEntrada = plans(k).faixaEntrada;
        faixaSaida   = plans(k).faixaSaida;
        CEL          = plans(k).CEL;
        SERIE        = plans(k).SERIE;
        nh           = plans(k).nh;
        nit          = 10;
        Cic          = 100000;
        file         = plans(k).mat;
        gravarExcel  = 1;
        arquivoCSV   = resultCsv;

        run_one_autoalt(EXCEL, PLAN, input, faixaEntrada, faixaSaida, ...
            CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV);

        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        fid = fopen(statusCsv, 'a');
        fprintf(fid, '%d;%s;%s;%s;%s;%s\n', k, plans(k).name, 'CONCLUIDO', inicio, fim, '');
        fclose(fid);

    catch ME
        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        msg = strrep(ME.message, ';', ',');
        msg = strrep(msg, sprintf('\n'), ' ');
        fid = fopen(statusCsv, 'a');
        fprintf(fid, '%d;%s;%s;%s;%s;%s\n', k, plans(k).name, 'ERRO', inicio, fim, msg);
        fclose(fid);
        disp(getReport(ME));
    end
end

disp('=== Treinamento 2h_alt RECORTE finalizado ===');
disp(datestr(now, 'yyyy-mm-dd HH:MM:SS'));

% Gerar RESULTADO_AUDITAVEL para o recorte
disp('Gerando arquivos RESULTADO_AUDITAVEL recorte...');
completaDirR = 'D:/PREVINE/redes_neurais/00_PLANILHAS2altrecorte/00_PLANILHAS_COMPLETAS_COM_INPUTS_E_RNA';
matDirR      = 'D:/PREVINE/redes_neurais/00_PLANILHAS2altrecorte/mat';
outDirR      = 'D:/PREVINE/redes_neurais/00_PLANILHAS2altrecorte/resultados_excel_auditaveis';
cmdR = ['python "D:/PREVINE/redes_neurais/gerar_resultados_auditaveis.py" ' ...
        '"' completaDirR '" "' matDirR '" "' outDirR '"' ...
        ' > "D:/PREVINE/redes_neurais/00_PLANILHAS2altrecorte/logs/auditaveis_log.txt" 2>&1'];
system(cmdR);
disp('RESULTADO_AUDITAVEL recorte gerados.');

% Gerar relatório comparativo automaticamente
disp('Gerando relatorio comparativo...');
system('python "D:/PREVINE/redes_neurais/00_PLANILHAS2altrecorte/gerar_relatorio_comparativo.py" > "D:/PREVINE/redes_neurais/00_PLANILHAS2altrecorte/logs/relatorio_log.txt" 2>&1');
disp('Relatorio gerado em 00_PLANILHAS2altrecorte/');

diary off;
exit;
