$ErrorActionPreference = 'Continue'
$log = 'D:\PREVINE\redes_neurais\RNA_TESTE_CRITERIO_EV_EQ_2026_07_03\wait_and_run_ev_eq.log'
function Write-Log($msg) {
  $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
  Add-Content -LiteralPath $log -Value "[$ts] $msg"
}
Write-Log 'Supervisor EV/EQ iniciado. Aguardando MATLAB atual encerrar.'
while (Get-Process -Name MATLAB -ErrorAction SilentlyContinue) {
  Start-Sleep -Seconds 60
}
Write-Log 'Nenhum MATLAB ativo. Iniciando teste EV/EQ.'
$matlab = 'C:\Program Files\MATLAB\R2014a\bin\win64\MATLAB.exe'
$arg = "-nosplash -nodesktop -r `"run('D:/PREVINE/redes_neurais/RNA_TESTE_CRITERIO_EV_EQ_2026_07_03/RUN_ALL_TESTE_CRITERIO_EV_EQ.m'); exit;`""
Start-Process -FilePath $matlab -ArgumentList $arg -WindowStyle Minimized
Write-Log 'MATLAB do teste EV/EQ iniciado.'
