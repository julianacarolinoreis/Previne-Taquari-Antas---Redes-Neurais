clear; clc;
codeDir = 'D:/PREVINE/redes_neurais/RNA_TESTE_CRITERIO_EV_EQ_2026_07_03/12H_ALT/EV_ATUAL/codigos';
addpath(codeDir);
resultCsv = 'D:/PREVINE/redes_neurais/RNA_TESTE_CRITERIO_EV_EQ_2026_07_03/12H_ALT/EV_ATUAL/resultados_12h_alt_ev_atual.csv';
statusCsv = 'D:/PREVINE/redes_neurais/RNA_TESTE_CRITERIO_EV_EQ_2026_07_03/12H_ALT/EV_ATUAL/status/status_12h_alt_ev_atual.csv';
logFile = 'D:/PREVINE/redes_neurais/RNA_TESTE_CRITERIO_EV_EQ_2026_07_03/12H_ALT/EV_ATUAL/logs/12H_ALT_EV_ATUAL.log';
if exist(resultCsv,'file'), delete(resultCsv); end
if exist(statusCsv,'file'), delete(statusCsv); end
fid=fopen(statusCsv,'w'); fprintf(fid,'ordem;familia;criterio_externo;criterio_interno;modelo;evt_teste;evt_valida;status;inicio;fim;mensagem\n'); fclose(fid);
diary(logFile);
disp('Teste criterio 12H_ALT EV_ATUAL iniciado');
plans = repmat(struct('orig_idx',0,'rot_id','','variant','','name','','tipo','','excel','','input',0,'nh',0,'faixaEntrada','','faixaSaida','','SERIE','','CEL','','mat','','evt_teste','','evt_valida',''), 1, 2);
plans(1).orig_idx = 1;
plans(1).rot_id = 'T12_V1_3';
plans(1).variant = 'NH_ORIG';
plans(1).name = 'T12_V1_3_NH_ORIG_003_alt_C0149_R01_T2_V1_3';
plans(1).tipo = 'alt';
plans(1).excel = 'D:/PREVINE/redes_neurais/RNA_MELHORIAS_12H_DIRIGIDAS_2026_07_03/01_12H_ALT_DIRIGIDA/planilhas/T12_V1_3_NH_ORIG_003_alt_C0149_R01_T2_V1_3.xlsx';
plans(1).input = 14;
plans(1).nh = 28;
plans(1).faixaEntrada = 'K2:X2913';
plans(1).faixaSaida = 'Y2:Y2913';
plans(1).SERIE = 'B2:B2913';
plans(1).CEL = 'AD2:AD2913';
plans(1).mat = 'D:/PREVINE/redes_neurais/RNA_TESTE_CRITERIO_EV_EQ_2026_07_03/12H_ALT/EV_ATUAL/mat/12H_ALT_EV_ATUAL_001_T12_V1_3_NH_ORIG_003_alt_C0149_R01_T2_V1_3.mat';
plans(1).evt_teste = '12';
plans(1).evt_valida = '1 3';
plans(2).orig_idx = 3;
plans(2).rot_id = 'T12_V1_3';
plans(2).variant = 'NH_ORIG';
plans(2).name = 'T12_V1_3_NH_ORIG_007_alt_C0237_R01_T2_V1_3';
plans(2).tipo = 'alt';
plans(2).excel = 'D:/PREVINE/redes_neurais/RNA_MELHORIAS_12H_DIRIGIDAS_2026_07_03/01_12H_ALT_DIRIGIDA/planilhas/T12_V1_3_NH_ORIG_007_alt_C0237_R01_T2_V1_3.xlsx';
plans(2).input = 15;
plans(2).nh = 30;
plans(2).faixaEntrada = 'K2:Y2863';
plans(2).faixaSaida = 'Z2:Z2863';
plans(2).SERIE = 'B2:B2863';
plans(2).CEL = 'AE2:AE2863';
plans(2).mat = 'D:/PREVINE/redes_neurais/RNA_TESTE_CRITERIO_EV_EQ_2026_07_03/12H_ALT/EV_ATUAL/mat/12H_ALT_EV_ATUAL_003_T12_V1_3_NH_ORIG_007_alt_C0237_R01_T2_V1_3.mat';
plans(2).evt_teste = '12';
plans(2).evt_valida = '1 3';

for k=1:length(plans)
    inicio = datestr(now, 'yyyy-mm-dd HH:MM:SS');
    fprintf('\n==== %d/%d %s %s ====\n', k, length(plans), plans(k).name, 'EV_ATUAL');
    fid=fopen(statusCsv,'a'); fprintf(fid,'%d;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s\n', k, '12H_ALT', 'EV', 'EV', plans(k).name, plans(k).evt_teste, plans(k).evt_valida, 'INICIADO', inicio, '', ''); fclose(fid);
    try
        try, rng(12000 + plans(k).orig_idx, 'twister'); catch, rand('seed',12000 + plans(k).orig_idx); randn('seed',22000 + plans(k).orig_idx); end
        EXCEL = plans(k).excel;
        PLAN = 'DADOS';
        input = plans(k).input;
        faixaEntrada = plans(k).faixaEntrada;
        faixaSaida = plans(k).faixaSaida;
        CEL = plans(k).CEL;
        SERIE = plans(k).SERIE;
        nh = plans(k).nh;
        nit = 10;
        Cic = 100000;
        file = plans(k).mat;
        gravarExcel = 0;
        arquivoCSV = resultCsv;
        CRITERIO_EXTERNO = 'EV';
        run_one_autoalt(EXCEL, PLAN, input, faixaEntrada, faixaSaida, CEL, SERIE, nh, nit, Cic, file, gravarExcel, arquivoCSV);
        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        fid=fopen(statusCsv,'a'); fprintf(fid,'%d;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s\n', k, '12H_ALT', 'EV', 'EV', plans(k).name, plans(k).evt_teste, plans(k).evt_valida, 'CONCLUIDO', inicio, fim, ''); fclose(fid);
    catch ME
        fim = datestr(now, 'yyyy-mm-dd HH:MM:SS');
        msg = strrep(ME.message, ';', ',');
        msg = strrep(msg, sprintf('\n'), ' ');
        fid=fopen(statusCsv,'a'); fprintf(fid,'%d;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s\n', k, '12H_ALT', 'EV', 'EV', plans(k).name, plans(k).evt_teste, plans(k).evt_valida, 'ERRO', inicio, fim, msg); fclose(fid);
        disp(getReport(ME));
    end
end
disp('Teste criterio 12H_ALT EV_ATUAL finalizado');
diary off;
