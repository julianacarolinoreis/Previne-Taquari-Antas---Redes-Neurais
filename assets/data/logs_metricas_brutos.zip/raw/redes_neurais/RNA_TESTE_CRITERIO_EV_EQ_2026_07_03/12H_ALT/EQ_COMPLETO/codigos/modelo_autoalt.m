% SCRIPT PARA PREVISAO DE SERIE TEMPORAL COM REDES NEURAIS ARTIFICIAIS:
% MODELO RNA ALTER 4H / D4H

clearvars -except PLAN input EXCEL CEL SERIE faixaEntrada faixaSaida nh nit Cic file gravarExcel arquivoCSV CRITERIO_EXTERNO
close all
clc
tic

disp('Carregando dados... MODELO RNA ALTER 4H / D4H')

if ~exist('EXCEL','var'), EXCEL='teste1alt4h.xlsx'; end
if ~exist('PLAN','var'), PLAN='Planilha2'; end
if ~exist('input','var'), input=14; end
if ~exist('faixaEntrada','var'), faixaEntrada='I3:V1594'; end
if ~exist('faixaSaida','var'), faixaSaida='W3:W1594'; end
if ~exist('CEL','var'), CEL='Y3:Y1594'; end
if ~exist('SERIE','var'), SERIE='AD3:AD1594'; end

if ~exist('nh','var'), nh=21; end
if ~exist('nit','var'), nit=5; end
if ~exist('Cic','var'), Cic=120000; end
if ~exist('file','var'), file='RNAPREV_AUTO.mat'; end
if ~exist('gravarExcel','var'), gravarExcel=1; end
if ~exist('arquivoCSV','var'), arquivoCSV='resultados_modelos.csv'; end

DADOS=[];
DADOS(:,1:input)=xlsread(EXCEL, PLAN, faixaEntrada);
DADOS(:,input+1)=xlsread(EXCEL, PLAN, faixaSaida);

f=0.05;
Prc=0.001;
Mom=0;

X(:,1)=xlsread(EXCEL,PLAN,SERIE);
treina=[]; valida=[]; verifica=[];

for i=1:size(X,1)
    if X(i)==1
        treina=[treina; DADOS(i,:)];
    elseif X(i)==2
        valida=[valida; DADOS(i,:)];
    else
        verifica=[verifica; DADOS(i,:)];
    end
end

disp('Carregamento de dados concluida!')

unisig=inline('1./(1+exp(-n))');
dunisig=inline('max(a.*(1-a),0.01)');
limsup=inline('max(v,[],2)+(max(v,[],2)-min(v,[],2)).*f','v','f');
liminf=inline('min(v,[],2)-(max(v,[],2)-min(v,[],2)).*f','v','f');
esclin=inline('(v-b*u)./(a*u)','v','a','b','u');
reclin=inline('(a*u).*s+b*u','s','a','b','u');

Pt=treina(:,1:input)'; Tt=treina(:,input+1:end)';
Ptv=valida(:,1:input)'; Ttv=valida(:,input+1:end)';
Pv=verifica(:,1:input)'; Tv=verifica(:,input+1:end)';
Ptot=DADOS(:,1:input)'; Ttot=DADOS(:,input+1:end)';

CRITmin=1000000000000000;
if ~exist('CRITERIO_EXTERNO','var'), CRITERIO_EXTERNO='EV'; end

As=unisig;
Ds=dunisig;
Ah=unisig;
Dh=dunisig;

Ut=ones(1,size(Pt,2));
Utv=ones(1,size(Ptv,2));
Uv=ones(1,size(Pv,2));
Utot=ones(1,size(Ptot,2));

disp('Realizando o escalonamento dos dados...')

ae=std(Pt,[],2);
be=mean(Pt,2);

ls=limsup(Tt,f);
li=liminf(Tt,f);
au=ls-li;
bu=li;

pt=esclin(Pt,ae,be,Ut);
ptv=esclin(Ptv,ae,be,Utv);
pv=esclin(Pv,ae,be,Uv);
ptot=esclin(Ptot,ae,be,Utot);

tt=esclin(Tt,au,bu,Ut);
ttv=esclin(Ttv,au,bu,Utv);
tv=esclin(Tv,au,bu,Uv);
ttot=esclin(Ttot,au,bu,Utot);

disp('Iniciando o treinamento da rede neural artificial...')

for i=1:nit
    [wh,bh,ws,bs,J,EQ,EV,TX,DE] = Retroprvcfn2(pt,tt,ptv,ttv,Ah,Dh,As,Ds,nh,Cic,Prc,Mom);

    if strcmpi(CRITERIO_EXTERNO,'EQ')
        criterio_iter = EQ(:,end);
    else
        criterio_iter = EV(:,end);
    end
    if criterio_iter<CRITmin
        CRITmin=criterio_iter;
        CRITERIO_ESCOLHA=CRITERIO_EXTERNO;
        save(file,'wh','bh','ws','bs','J','EQ','EV','TX','DE','ae','be','au','bu','CRITERIO_ESCOLHA')
    end

    format bank
    disp([num2str(i/nit*100),'% CONCLUIDO'])
end

disp('Rede neural artificial treinada!')
disp('Calculando metricas de desempenho da RNA para simulacao...')

load(file)

ATUAL_TOT=DADOS(:,1)';
ATUAL_TRE=treina(:,1)';
ATUAL_VER=verifica(:,1)';
ATUAL_VAL=valida(:,1)';

Tctre1=reclin(As(ws*Ah(wh*pt+bh*Ut)+bs*Ut),au,bu,Ut)+ATUAL_TRE;
Tctot1=reclin(As(ws*Ah(wh*ptot+bh*Utot)+bs*Utot),au,bu,Utot)+ATUAL_TOT;
Tc1=reclin(As(ws*Ah(wh*pv+bh*Uv)+bs*Uv),au,bu,Uv)+ATUAL_VER;
Tcval1=reclin(As(ws*Ah(wh*ptv+bh*Utv)+bs*Utv),au,bu,Utv)+ATUAL_VAL;

Tt1=Tt+ATUAL_TRE;
Ttot1=Ttot+ATUAL_TOT;
Tv1=Tv+ATUAL_VER;
Ttv1=Ttv+ATUAL_VAL;

eabs=abs(Tv1-Tc1);
emed_abs=mean(eabs);

p=[50 80 90 95 99 100];
g=prctile(eabs,p);

e2=(Tv1-Tc1).^2;
e2val=(Ttv1-Tcval1).^2;

NASH=1-sum(sum(e2))/sum(sum((Tv1-mean(mean(Tv1))).^2));
NASH_VAL=1-sum(sum(e2val))/sum(sum((Ttv1-mean(mean(Ttv1))).^2));

MPERS=verifica(:,1)';
PERS=1-sum(sum(e2))/sum(sum((Tv1-MPERS).^2));

e_tre=Tt1-Tctre1; e_val=Ttv1-Tcval1; e_tes=Tv1-Tc1; e_ger=Ttot1-Tctot1;
PERS_TREINO=1-sum(sum(e_tre.^2))/sum(sum((Tt1-ATUAL_TRE).^2));
PERS_VALIDACAO=1-sum(sum(e_val.^2))/sum(sum((Ttv1-ATUAL_VAL).^2));
PERS_TESTE=1-sum(sum(e_tes.^2))/sum(sum((Tv1-ATUAL_VER).^2));
PERS_GERAL=1-sum(sum(e_ger.^2))/sum(sum((Ttot1-ATUAL_TOT).^2));
NASH_TREINO=1-sum(sum(e_tre.^2))/sum(sum((Tt1-mean(mean(Tt1))).^2));
NASH_TESTE=NASH;
NASH_VALIDACAO=NASH_VAL;
NASH_GERAL=1-sum(sum(e_ger.^2))/sum(sum((Ttot1-mean(mean(Ttot1))).^2));
MAE_TREINO=mean(abs(e_tre)); MAE_VALIDACAO=mean(abs(e_val)); MAE_TESTE=mean(abs(e_tes)); MAE_GERAL=mean(abs(e_ger));
E95_TREINO=prctile(abs(e_tre),95); E95_VALIDACAO=prctile(abs(e_val),95); E95_TESTE=prctile(abs(e_tes),95); E95_GERAL=prctile(abs(e_ger),95);
CORR_TREINO=corrcoef(Tctre1,Tt1); CORR_VALIDACAO=corrcoef(Tcval1,Ttv1); CORR_TESTE=corrcoef(Tc1,Tv1); CORR_GERAL=corrcoef(Tctot1,Ttot1);
N_GERAL=size(Ttot1,2); N_TREINO=size(Tt1,2); N_VALIDACAO=size(Ttv1,2); N_TESTE=size(Tv1,2);

CORRELACAO=corrcoef(Tc1,Tv1);
ERRO_RELATIVO=mean(mean(eabs./Tv1));
emed_abs_mean=emed_abs/mean(mean(Tv1));
e95=g(1,4);

format short

RESULTS=[NASH;PERS;CORRELACAO(1,2);ERRO_RELATIVO;emed_abs_mean;e95;NASH_VAL;J];

save(file)

disp('Coeficiente de Nash Sutcliffe teste = ')
disp(num2str(NASH))
disp('Coeficiente de Nash Sutcliffe validacao = ')
disp(num2str(NASH_VAL))
disp('Coeficiente de Persistencia = ')
disp(num2str(PERS))
disp('Coeficiente de Correlacao = ')
disp(num2str(CORRELACAO(1,2)))
disp('Erro Absoluto Medio = ')
disp(num2str(emed_abs))
disp('Erro Percentual = ')
disp(num2str(ERRO_RELATIVO))
disp('Erro 95% = ')
disp(num2str(e95))
disp('J = ')
disp(num2str(J))

fid=fopen(arquivoCSV,'a');

if ftell(fid)==0
    fprintf(fid,'PLAN;input;faixaEntrada;faixaSaida;CEL;SERIE;nh;nit;Cic;J;NASH_VAL;NASH_TESTE;PERS;CORRELACAO;ERRO_RELATIVO;ERRO_ABS_MEDIO;E95;arquivo_mat\n');
end

fprintf(fid,'%s;%d;%s;%s;%s;%s;%d;%d;%d;%d;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%s\n', ...
    PLAN,input,faixaEntrada,faixaSaida,CEL,SERIE,nh,nit,Cic,J,NASH_VAL,NASH,PERS,CORRELACAO(1,2),ERRO_RELATIVO,emed_abs,e95,file);

fclose(fid);

arquivoCSVCompleto=strrep(arquivoCSV,'.csv','_metricas_completas.csv');
fid=fopen(arquivoCSVCompleto,'a');
[~,MODELO_NOME,~]=fileparts(file);
TIPO_MODELO='alt';

if ftell(fid)==0
    fprintf(fid,'MODELO;TIPO;PLAN;input;faixaEntrada;faixaSaida;CEL;SERIE;nh;nit;Cic;J;N_GERAL;N_TREINO;N_VALIDACAO;N_TESTE;NASH_GERAL;NASH_TREINO;NASH_VALIDACAO;NASH_TESTE;PERS_GERAL;PERS_TREINO;PERS_VALIDACAO;PERS_TESTE;MAE_GERAL;MAE_TREINO;MAE_VALIDACAO;MAE_TESTE;E95_GERAL;E95_TREINO;E95_VALIDACAO;E95_TESTE;CORR_GERAL;CORR_TREINO;CORR_VALIDACAO;CORR_TESTE;arquivo_mat\n');
end

fprintf(fid,'%s;%s;%s;%d;%s;%s;%s;%s;%d;%d;%d;%d;%d;%d;%d;%d;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%s\n', ...
    MODELO_NOME,TIPO_MODELO,PLAN,input,faixaEntrada,faixaSaida,CEL,SERIE,nh,nit,Cic,J,N_GERAL,N_TREINO,N_VALIDACAO,N_TESTE,NASH_GERAL,NASH_TREINO,NASH_VALIDACAO,NASH_TESTE,PERS_GERAL,PERS_TREINO,PERS_VALIDACAO,PERS_TESTE,MAE_GERAL,MAE_TREINO,MAE_VALIDACAO,MAE_TESTE,E95_GERAL,E95_TREINO,E95_VALIDACAO,E95_TESTE,CORR_GERAL(1,2),CORR_TREINO(1,2),CORR_VALIDACAO(1,2),CORR_TESTE(1,2),file);

fclose(fid);

rnaout=Tctot1';

if gravarExcel==1
    disp('Tentando salvar no Excel oficial...')
    [status,msg] = xlswrite(EXCEL,rnaout,PLAN,CEL);

    if status == 1
        disp('Excel oficial salvo com sucesso!')
    else
        disp('Falha ao salvar no Excel oficial:')
        disp(msg.message)
    end
else
    disp('gravarExcel=0: Excel oficial nao foi salvo nesta rodada.')
end

toc
