% SCRIPT PARA PREVISAO DE SERIE TEMPORAL COM REDES NEURAIS ARTIFICIAIS:
% MODELO RNA ALTER 4H / D4H  -- VERSAO COM ROTACAO DE EVENTOS
% evt_teste : array de IDs de evento para TESTE    (serie=3)
% evt_valida: array de IDs de evento para VALIDACAO (serie=2)
% Demais eventos (incluindo fixos 4/set23, 5/nov23, 7/abr24, 8/abr-mai24) => TREINO (serie=1)

clearvars -except PLAN input EXCEL CEL SERIE faixaEntrada faixaSaida nh nit Cic file gravarExcel arquivoCSV evt_teste evt_valida CRITERIO_EXTERNO
close all
clc
tic

disp('Carregando dados... MODELO RNA ALTER [ROT EVENTOS]')

if ~exist('EXCEL','var'), EXCEL='teste1alt4h.xlsx'; end
if ~exist('PLAN','var'),  PLAN='Planilha2'; end
if ~exist('input','var'), input=14; end
if ~exist('faixaEntrada','var'), faixaEntrada='I3:V1594'; end
if ~exist('faixaSaida','var'),   faixaSaida='W3:W1594'; end
if ~exist('CEL','var'),   CEL='Y3:Y1594'; end
if ~exist('SERIE','var'), SERIE='AD3:AD1594'; end
if ~exist('nh','var'),    nh=21; end
if ~exist('nit','var'),   nit=5; end
if ~exist('Cic','var'),   Cic=120000; end
if ~exist('file','var'),  file='RNAPREV_AUTO.mat'; end
if ~exist('gravarExcel','var'), gravarExcel=0; end
if ~exist('arquivoCSV','var'),  arquivoCSV='resultados_modelos.csv'; end
if ~exist('evt_teste','var'),   evt_teste=[]; end
if ~exist('evt_valida','var'),  evt_valida=[]; end

DADOS=[];
DADOS(:,1:input)=xlsread(EXCEL, PLAN, faixaEntrada);
DADOS(:,input+1)=xlsread(EXCEL, PLAN, faixaSaida);

f=0.05; Prc=0.001; Mom=0;

X(:,1)=xlsread(EXCEL,PLAN,SERIE);

% ── Rotacao de eventos ────────────────────────────────────────────────────────
% FIXOS TREINO: eventos que NUNCA podem ser Teste ou Validacao
% 4=set/23, 5=nov/23, 7=abr/24, 8=abr-mai/24
EVTS_FIXO_TREINO = [4, 5, 7, 8];
if ~isempty(evt_teste)
    EVTCOL = strrep(SERIE, 'B', 'A');
    X_evt = xlsread(EXCEL, PLAN, EVTCOL);
    for ii = 1:size(X_evt,1)
        ev = X_evt(ii);
        if ismember(ev, EVTS_FIXO_TREINO)
            X(ii,1) = 1;  % forcado Treino independente de evt_teste/evt_valida
        elseif ismember(ev, evt_teste)
            X(ii,1) = 3;
        elseif ismember(ev, evt_valida)
            X(ii,1) = 2;
        else
            X(ii,1) = 1;
        end
    end
    clear EVTCOL X_evt ii ev
end
% ─────────────────────────────────────────────────────────────────────────────

treina=[]; valida=[]; verifica=[];
for i=1:size(X,1)
    if X(i)==1
        treina=[treina; DADOS(i,:)];
    elseif X(i)==2
        valida=[valida; DADOS(i,:)];
    else
        verifica=[verifica; DADOS(i,:)];
    end
end
disp('Carregamento de dados concluida!')

unisig=inline('1./(1+exp(-n))');
dunisig=inline('max(a.*(1-a),0.01)');
limsup=inline('max(v,[],2)+(max(v,[],2)-min(v,[],2)).*f','v','f');
liminf=inline('min(v,[],2)-(max(v,[],2)-min(v,[],2)).*f','v','f');
esclin=inline('(v-b*u)./(a*u)','v','a','b','u');
reclin=inline('(a*u).*s+b*u','s','a','b','u');

Pt=treina(:,1:input)'; Tt=treina(:,input+1:end)';
Ptv=valida(:,1:input)'; Ttv=valida(:,input+1:end)';
Pv=verifica(:,1:input)'; Tv=verifica(:,input+1:end)';
Ptot=DADOS(:,1:input)'; Ttot=DADOS(:,input+1:end)';

CRITmin=1000000000000000;
if ~exist('CRITERIO_EXTERNO','var'), CRITERIO_EXTERNO='EV'; end
As=unisig; Ds=dunisig; Ah=unisig; Dh=dunisig;
Ut=ones(1,size(Pt,2)); Utv=ones(1,size(Ptv,2));
Uv=ones(1,size(Pv,2)); Utot=ones(1,size(Ptot,2));

disp('Realizando o escalonamento dos dados...')
ae=std(Pt,[],2); be=mean(Pt,2);
ls=limsup(Tt,f); li=liminf(Tt,f); au=ls-li; bu=li;
pt=esclin(Pt,ae,be,Ut); ptv=esclin(Ptv,ae,be,Utv);
pv=esclin(Pv,ae,be,Uv); ptot=esclin(Ptot,ae,be,Utot);
tt=esclin(Tt,au,bu,Ut); ttv=esclin(Ttv,au,bu,Utv);
tv=esclin(Tv,au,bu,Uv); ttot=esclin(Ttot,au,bu,Utot);

disp('Iniciando o treinamento da rede neural artificial...')
for i=1:nit
    [wh,bh,ws,bs,J,EQ,EV,TX,DE] = Retroprvcfn2(pt,tt,ptv,ttv,Ah,Dh,As,Ds,nh,Cic,Prc,Mom);
    if strcmpi(CRITERIO_EXTERNO,'EQ')
        criterio_iter = EQ(:,end);
    else
        criterio_iter = EV(:,end);
    end
    if criterio_iter<CRITmin
        CRITmin=criterio_iter;
        CRITERIO_ESCOLHA=CRITERIO_EXTERNO;
        save(file,'wh','bh','ws','bs','J','EQ','EV','TX','DE','ae','be','au','bu','CRITERIO_ESCOLHA')
    end
    format bank
    disp([num2str(i/nit*100),'% CONCLUIDO'])
end
disp('Rede neural artificial treinada!')

load(file)
ATUAL_TOT=DADOS(:,1)'; ATUAL_VER=verifica(:,1)'; ATUAL_VAL=valida(:,1)';
Tctot1=reclin(As(ws*Ah(wh*ptot+bh*Utot)+bs*Utot),au,bu,Utot)+ATUAL_TOT;
Tc1=reclin(As(ws*Ah(wh*pv+bh*Uv)+bs*Uv),au,bu,Uv)+ATUAL_VER;
Tcval1=reclin(As(ws*Ah(wh*ptv+bh*Utv)+bs*Utv),au,bu,Utv)+ATUAL_VAL;
Tv1=Tv+ATUAL_VER; Ttv1=Ttv+ATUAL_VAL;

eabs=abs(Tv1-Tc1); emed_abs=mean(eabs);
p=[50 80 90 95 99 100]; g=prctile(eabs,p);
e2=(Tv1-Tc1).^2; e2val=(Ttv1-Tcval1).^2;
NASH=1-sum(sum(e2))/sum(sum((Tv1-mean(mean(Tv1))).^2));
NASH_VAL=1-sum(sum(e2val))/sum(sum((Ttv1-mean(mean(Ttv1))).^2));
MPERS=verifica(:,1)';
PERS=1-sum(sum(e2))/sum(sum((Tv1-MPERS).^2));
CORRELACAO=corrcoef(Tc1,Tv1);
ERRO_RELATIVO=mean(mean(eabs./Tv1));
emed_abs_mean=emed_abs/mean(mean(Tv1));
e95=g(1,4);
format short
RESULTS=[NASH;PERS;CORRELACAO(1,2);ERRO_RELATIVO;emed_abs_mean;e95;NASH_VAL;J];
save(file)

disp(['Nash Teste=', num2str(NASH), ' | Nash Val=', num2str(NASH_VAL)])

fid=fopen(arquivoCSV,'a');
if ftell(fid)==0
    fprintf(fid,'rot_id;PLAN;input;faixaEntrada;faixaSaida;CEL;SERIE;evt_teste;evt_valida;nh;nit;Cic;J;NASH_VAL;NASH_TESTE;PERS;CORRELACAO;ERRO_RELATIVO;ERRO_ABS_MEDIO;E95;arquivo_mat\n');
end
fprintf(fid,'%s;%s;%d;%s;%s;%s;%s;%s;%s;%d;%d;%d;%d;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%.10f;%s\n', ...
    arquivoCSV,PLAN,input,faixaEntrada,faixaSaida,CEL,SERIE, ...
    num2str(evt_teste),num2str(evt_valida), ...
    nh,nit,Cic,J,NASH_VAL,NASH,PERS,CORRELACAO(1,2),ERRO_RELATIVO,emed_abs,e95,file);
fclose(fid);

if gravarExcel==1
    rnaout=Tctot1';
    disp('Salvando no Excel...')
    [status,msg] = xlswrite(EXCEL,rnaout,PLAN,CEL);
    if status==1, disp('Excel salvo!'); else, disp(['Falha Excel: ' msg.message]); end
end
toc
