@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "D:\PREVINE\redes_neurais\RNA_TESTE_CRITERIO_EV_EQ_2026_07_03\AGUARDAR_MATLAB_E_RODAR_TESTE_EV_EQ.ps1"
