@echo off
echo [%DATE% %TIME%] Encerrando instancias duplicadas da fila...
taskkill /F /FI "WINDOWTITLE eq fila_rotacao_eventos" /T 2>nul
timeout /T 3 /NOBREAK >nul
if exist "D:\PREVINE\redes_neurais\fila_rotacao_eventos.lock" (
    del "D:\PREVINE\redes_neurais\fila_rotacao_eventos.lock"
    echo Lock file removido.
)
echo [%DATE% %TIME%] Reiniciando fila (instancia unica)...
start "fila_rotacao_eventos" /MIN cmd /C "C:\Users\Usuario\AppData\Local\Python\bin\python.exe "D:\PREVINE\redes_neurais\fila_rotacao_eventos.py""
echo Fila reiniciada (instancia unica, lock ativo).
echo Log em: D:\PREVINE\redes_neurais\fila_rotacao_eventos.log
timeout /T 3
