# Análise de Eventos Problemáticos — Redes Neurais Santa Tereza (ANA 56472600)

**Data:** 2026-07-01  
**Estação:** Santa Tereza, Rio das Antas, RS  
**Categorias analisadas:** 2H_ALT, 2H_CONV, 8H_ALT, 8H_SENTINELA, 8H_CONV  
**Total de modelos analisados:** 219 execuções de rotação  
**Fontes:** resultados_rotacao_2h_reduzida.csv (37), resultados_rotacao_8h_conv_corrigida.csv (36), resultados_exploracao_8h_alt.csv (48), resultados_rotacao_8h_sentinela.csv (30 modelos × 3 validações = 90), resultados_rotacao_2h_conv_corrigida.csv (8)

---

## 1. Mapeamento Evento → Período

| Evt | Período            | Obs  | Status         | Características                        |
|-----|--------------------|------|----------------|----------------------------------------|
| 1   | 2023-05-04→12      |  93  | Rotacionável   | Curto (~8 dias, mai/23)                |
| 2   | 2023-06-15→28      | 115  | Rotacionável   | jun/23                                 |
| 3   | 2023-07-08→27      | 238  | Rotacionável   | jul/23                                 |
| 4   | 2023-09-03→25      | 509  | **Fixo treino**| set/23 (maior evento do dataset)       |
| 5   | 2023-11-10→12-27   | 220  | **Fixo treino**| nov/23                                 |
| 7   | 2024-04-14→20      | 140  | Rotacionável   | abr/24 (~7 dias úteis)                 |
| 8   | 2024-04-27→05-02   |  84  | **Fixo treino**| mai/24                                 |
| 12  | 2024-09-30→10-18   | 393  | Rotacionável   | set/out-24 (evento longo de outono)    |
| 13  | 2024-12-25→25      |   6  | **Excluído**   | 6 obs apenas (descontinuidade)         |
| 14  | 2024-12-28→01-02   |  95  | Rotacionável   | dez/24-jan/25 (~5 dias)                |
| 18  | 2025-07-20→08-02   | 272  | Rotacionável   | jul/25                                 |
| 19  | 2025-08-16→29      | 308  | Rotacionável   | ago/25                                 |
| 20  | 2025-09-02→22      | 346  | Rotacionável   | set/25                                 |

---

## 2. Ranking de Eventos como TESTE (mais problemático → menos problemático)

| Rank | Evt | Período        | n  | NASH_TESTE_med | NASH_TESTE_min | PERS_GERAL_med | NASH<0 | PERS<0 | Categorias                |
|------|-----|----------------|----|----------------|----------------|----------------|--------|--------|---------------------------|
| **1**| **7** | **abr/24** | **6** | **0.0786** | **−0.5846** | **−0.8713** | **2** | **5** | 8H_CONV            |
| **2**| **14**| **dez/24**  | **6** | **0.6061** | **0.4746**  | **−0.2178** | **0** | **4** | 8H_CONV            |
| **3**| **12**| **set/out-24**| **6** | **0.7105** | **0.5364** | **−0.4853** | **0** | **5** | 8H_CONV            |
| 4   | 1   | mai/23         | 157| 0.8804         | 0.6362         | 0.3712         | 0      | 24     | 2H_ALT, 8H_ALT, 8H_CONV, 8H_SENTINELA |
| 5   | 3   | jul/23         | 18 | 0.9116         | 0.8128         | 0.5541         | 0      | 0      | 8H_ALT, 8H_CONV           |
| 6   | 2   | jun/23         | 26 | 0.9243         | 0.7421         | 0.3322         | 0      | 5      | 2H_CONV, 8H_ALT, 8H_CONV |

> **Nota:** Evento 7 é extremamente problemático. Duas de seis redes ficam com NASH_TESTE **negativo** (piores que persistência), e cinco das seis têm PERS_GERAL negativo. O pior valor individual é PERS_GERAL = −2.218 (8H_CONV, evt_teste=7, valida=1+2).

---

## 3. Ranking de Eventos na VALIDAÇÃO (maior impacto negativo no PERS_GERAL)

Metodologia: para cada evento rotacionável, compara-se PERS_GERAL médio de todas as rodadas onde aquele evento está na validação vs. onde não está.

| Rank | Evt | Período    | n_com | PERS_GERAL_com | PERS_GERAL_sem | Δ_PERS   | PERS_neg% | Interpretação         |
|------|-----|------------|-------|----------------|----------------|----------|-----------|-----------------------|
| **1**| **1** | **mai/23**| **62**| **0.1478**   | **0.3712**     | **−0.2234** | **30.6%** | Prejudicial        |
| 2   | 2   | jun/23     | 193   | 0.3047         | 0.3322         | −0.0274  | 19.7%     | Levemente prejudicial |
| 3   | 3   | jul/23     | 86    | 0.3314         | 0.2928         | +0.038   | 19.8%     | Neutro/levemente bom  |
| 4   | 12  | set/out-24 | 42    | 0.3870         | 0.2892         | +0.098   | 14.3%     | Levemente benéfico    |
| 5   | 7   | abr/24     | 54    | 0.3983         | 0.2784         | +0.120   | 11.1%     | Levemente benéfico    |
| 6   | 14  | dez/24     | 1     | 0.6538         | 0.3064         | +0.347   | 0.0%      | Benéfico (n=1)        |

> **Detalhe para 8H Sentinela** (mesmo modelo, mesmo evento teste=1, apenas validação varia):  
> — Validação 2+3 → PERS_GERAL médio = 0.3825  
> — Validação 2+7 → PERS_GERAL médio = 0.3276 (Δ = −0.055)  
> — Validação 2+12 → PERS_GERAL médio = 0.3202 (Δ = −0.062)  
> Ou seja: incluir evt 7 ou 12 na validação reduz levemente o PERS_GERAL, mas não de forma crítica.

---

## 4. Análise por Categoria

### NASH_TESTE médio por categoria e evento de teste

| Categoria     | Evt_teste | NASH_TESTE_med | PERS_GERAL_med | n  |
|---------------|-----------|----------------|----------------|----|
| 2H_ALT        | 1         | **0.9837**     | 0.5025         | 37 |
| 2H_CONV       | 2         | 0.9675         | **−0.2246**    | 8  |
| 8H_ALT        | 1         | 0.8007         | 0.3386         | 24 |
| 8H_ALT        | 2         | 0.9081         | 0.5923         | 12 |
| 8H_ALT        | 3         | 0.9338         | 0.6657         | 12 |
| 8H_CONV       | 1         | 0.7215         | 0.1089         | 6  |
| 8H_CONV       | 2         | 0.8989         | 0.5543         | 6  |
| 8H_CONV       | 3         | 0.8673         | 0.3310         | 6  |
| **8H_CONV**   | **7**     | **0.0786**     | **−0.8713**    | 6  |
| 8H_CONV       | 12        | 0.7105         | −0.4853        | 6  |
| 8H_CONV       | 14        | 0.6061         | −0.2178        | 6  |
| 8H_SENTINELA  | 1         | 0.8698         | 0.3435         | 90 |

### Paradoxo 2H_CONV

Na 2H_CONV, o evento 2 (jun/23) como teste produz **NASH_TESTE médio excelente (0.9675)** mas **PERS_GERAL médio negativo (−0.2246)**. Isso ocorre exclusivamente nas rotações com validação "1+3":

| evt_validacao | NASH_TESTE | PERS_GERAL | n |
|---------------|------------|------------|---|
| 1 3           | 0.9492     | **−0.9119** | 5 |
| Outros        | ~0.97      | ≥ 0.45     | 3 |

O modelo aprende bem o evt 2 no teste, mas não generaliza para os demais eventos da série — típico de sobreajuste ao conjunto de treino quando evt 1 (evento mais curto e de padrão distinto) está na validação e não contribui para o treino de forma representativa.

---

## 5. Os 10 Piores Resultados Individuais (NASH_TESTE)

| #  | Categoria | Evt_teste | Evt_validacao | NASH_TESTE | PERS_GERAL |
|----|-----------|-----------|---------------|------------|------------|
| 1  | 8H_CONV   | 7         | 1 2           | −0.5846    | −2.2182    |
| 2  | 8H_CONV   | 7         | 1 2           | −0.0042    | −1.0394    |
| 3  | 8H_CONV   | 7         | 1 2           | 0.0614     | −0.9062    |
| 4  | 8H_CONV   | 7         | 1 2           | 0.1796     | −0.6661    |
| 5  | 8H_CONV   | 7         | 1 2           | 0.3025     | −0.4166    |
| 6  | 8H_CONV   | 14        | 1 2           | 0.4746     | −0.6342    |
| 7  | 8H_CONV   | 7         | 1 2           | 0.5169     | +0.0188    |
| 8  | 8H_CONV   | 14        | 1 2           | 0.5344     | −0.4048    |
| 9  | 8H_CONV   | 12        | 1 2           | 0.5364     | −1.2752    |
| 10 | 8H_CONV   | 14        | 1 2           | 0.5501     | −0.3924    |

> **Todos os 10 piores são 8H_CONV com evt_teste ∈ {7, 12, 14}.** O evt 7 domina as posições mais críticas.

---

## 6. Padrão Cross-Categoria

### Evento 7 (abr/24) — impacto consistente

Testado apenas em **8H_CONV** (6 rodadas), mas de forma devastadora. O AJUSTE_FILA já registrou explicitamente a exclusão de rotações onde evt 7, 12 ou 14 apareciam na **validação** de 8H_CONV ("validacao contem evento 7/12/14, que derrubou PERS_validacao"), indicando que o problema é anterior ao presente experimento e recorrente.

### Evento 12 e 14 — problemáticos como teste em 8H

Ambos aparecem apenas nos experimentos 8H_CONV. O evento 12 (set/out-24, 393 obs) é longo mas tem características sazonais distintas (outono). O evento 14 (dez/24-jan/25) é muito curto (95 obs, ~5 dias), característico de verão.

### Evento 1 (mai/23) — problema estrutural na validação

É o único evento cuja presença na **validação** reduz sistematicamente o PERS_GERAL (Δ = −0.2234, com 30.6% dos modelos tendo PERS_GERAL negativo). O evento 1 é o mais curto do conjunto rotacionável (93 obs, ~8 dias) e o mais antigo, possivelmente representando condições hidrológicas subrepresentadas no restante da série.

---

## 7. Hipóteses Explicativas

### Por que Evento 7 (abr/24) como TESTE é tão destrutivo?

1. **Período atípico entre cheias:** O evento 7 ocorre entre dois eventos de cheia de abril (evt 7 = 14→20/abr, evt 8 = 27/abr→01/mai). É um evento de descida de cheia seguida de recessão rápida — padrão distinto dos grandes eventos de set/23 (evt 4) fixo no treino.
2. **Ausência de análogos no treino:** Quando evt 7 é reservado para teste, o modelo é treinado sem aquele padrão de recessão/reascensão rápida de abril. Com 8H de antecedência, a dinâmica de curto prazo desse tipo de evento é difícil de capturar.
3. **PERS negativo:** A persistência simples supera a RNA — isso indica que a rede está errando sistematicamente a tendência (provavelmente prevendo alta quando o rio está descendo, ou vice-versa).

### Por que Eventos 12 e 14 como TESTE têm PERS_GERAL negativo mas NASH_TESTE aceitável?

O PERS_GERAL é calculado sobre **todos os dados da série** (treino + validação + teste). Se a RNA performa bem no evt 12 ou 14 (NASH_TESTE > 0.5) mas o PERS_GERAL fica negativo, significa que em outros períodos da série o modelo desempenha abaixo da persistência — provavelmente porque, ao excluir evt 12 ou 14 do treino, o modelo overfita nos eventos de treino remanescentes.

### Por que Evento 1 (mai/23) prejudica a VALIDAÇÃO?

Com apenas 93 observações (~8 dias), o evento 1 é curto demais para servir como representação robusta da distribuição de desempenho. Quando está na validação, o early stopping/critério de seleção do treinamento pode favorecer modelos que se saem bem nesse evento pequeno mas não generalizam para toda a série.

### Por que 2H_CONV com evt_teste=2 tem paradoxo NASH/PERS?

O evento 2 (jun/23) tem 115 observações. Nas rotações 2H_CONV onde a validação é "1+3" (93+238 = 331 obs), o treino fica com os eventos maiores (set/23=509, nov/23=220, mai/24=84 = 813 obs). A RNA aprende excelentemente os grandes eventos no treino e reproduz bem o teste (evt 2, que tem escala semelhante). Mas o PERS_GERAL negativo indica que ela falha em partes da série não representadas pelos eventos de treino — especialmente os eventos futuros (18, 19, 20 de 2025) que têm características distintas.

---

## 8. Conclusões Operacionais

### Eventos a evitar como TESTE (para qualquer categoria 8H)

- **Evento 7 (abr/24):** Não usar como teste em hipótese alguma. Resultados são inválidos/sem utilidade operacional.
- **Evento 12 (set/out-24):** Usar com cautela. PERS_GERAL sistematicamente negativo mesmo com NASH_TESTE aceitável.
- **Evento 14 (dez/24-jan/25):** Problemático. PERS_GERAL negativo em 4/6 rodadas.

### Evento 7 nas categorias 2H (ainda não testado)

O evento 7 ainda **não foi testado como teste em 2H_ALT ou 2H_CONV**. Dado o padrão observado em 8H, há risco real de que seja igualmente destrutivo em 2H. Recomenda-se cautela ao incluí-lo como evento de teste nas próximas rotações.

### Validação: evento 1 é o mais arriscado

Quando evt 1 vai para validação (e não para treino), o PERS_GERAL mediano cai 0.22 pontos e 30.6% dos modelos ficam com PERS_GERAL negativo. Preferível usar evt 1 como treino (fixo) ou aceitar que rodadas com evt 1 na validação precisam de filtro de qualidade mais rigoroso.

### Combinações mais problemáticas confirmadas

- **8H_CONV com evt_valida ∈ {7, 12, 14}:** Explicitamente documentado no AJUSTE_FILA como rodadas descartadas por "derrubou PERS_validacao" — confirmado numericamente pela análise.
- **2H_CONV, evt_teste=2, validacao="1 3":** PERS_GERAL médio = −0.91 (5 rodadas).

---

## Apêndice: Evento 13 (excluído)

O evento 13 (2024-12-25, apenas 6 observações, ~5 horas) foi explicitamente excluído de todos os treinamentos. Suas 6 observações correspondem a uma descontinuidade/ruído no dado e sua presença contamina qualquer série de eventos, por isso foi removido antes do início das rotações.

---

*Análise gerada em 2026-07-01 com base em 219 rodadas de rotação executadas nos experimentos: RNA_2H_ROTACAO_REDUZIDA_SEM_EVT13, RNA_2H_CONV_ROTACAO_CORRIGIDA, RNA_8H_CONV_ROTACAO_CORRIGIDA, RNA_8H_ROTACAO_SENTINELA, RNA_8H_ALT_EXPLORACAO.*
